import { StockData, CryptoData, ChartData, MarketAsset } from '../types/market';

// Mock stock data
const mockStocks: StockData[] = [
  {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    price: 182.52,
    change: 1.23,
    changePercent: 0.68,
    volume: 58432100,
    marketCap: 2850000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    price: 417.88,
    change: 2.45,
    changePercent: 0.59,
    volume: 22145600,
    marketCap: 3100000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    price: 175.98,
    change: -0.87,
    changePercent: -0.49,
    volume: 18765400,
    marketCap: 2200000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'AMZN',
    name: 'Amazon.com Inc.',
    price: 178.75,
    change: 1.05,
    changePercent: 0.59,
    volume: 32456700,
    marketCap: 1850000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'TSLA',
    name: 'Tesla, Inc.',
    price: 175.34,
    change: -3.21,
    changePercent: -1.8,
    volume: 87654300,
    marketCap: 556000000000,
    lastUpdated: new Date().toISOString(),
  },
];

// Mock crypto data
const mockCryptos: CryptoData[] = [
  {
    symbol: 'BTC',
    name: 'Bitcoin',
    price: 68245.32,
    change: 1245.67,
    changePercent: 1.86,
    volume: 32456700000,
    marketCap: 1340000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'ETH',
    name: 'Ethereum',
    price: 3875.45,
    change: 87.23,
    changePercent: 2.3,
    volume: 18765400000,
    marketCap: 465000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'SOL',
    name: 'Solana',
    price: 145.78,
    change: -2.34,
    changePercent: -1.58,
    volume: 5432100000,
    marketCap: 63000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'ADA',
    name: 'Cardano',
    price: 0.45,
    change: 0.01,
    changePercent: 2.27,
    volume: 1234567000,
    marketCap: 16000000000,
    lastUpdated: new Date().toISOString(),
  },
  {
    symbol: 'XRP',
    name: 'XRP',
    price: 0.52,
    change: -0.01,
    changePercent: -1.89,
    volume: 2345678000,
    marketCap: 28000000000,
    lastUpdated: new Date().toISOString(),
  },
];

// Generate mock chart data
const generateMockChartData = (basePrice: number, days = 30): ChartData[] => {
  const data: ChartData[] = [];
  let currentPrice = basePrice;
  
  for (let i = days; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    const volatility = basePrice * 0.02; // 2% volatility
    const changePercent = (Math.random() - 0.5) * 2 * volatility;
    currentPrice = currentPrice + changePercent;
    
    const open = currentPrice;
    const high = open * (1 + Math.random() * 0.01);
    const low = open * (1 - Math.random() * 0.01);
    const close = (high + low) / 2;
    const volume = Math.floor(Math.random() * 10000000) + 1000000;
    
    data.push({
      date: date.toISOString().split('T')[0],
      open,
      high,
      low,
      close,
      volume,
    });
  }
  
  return data;
};

// Get all stocks
export const getStocks = async (): Promise<StockData[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  return mockStocks;
};

// Get all cryptos
export const getCryptos = async (): Promise<CryptoData[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  return mockCryptos;
};

// Get asset by symbol
export const getAssetBySymbol = async (symbol: string, type: 'stock' | 'crypto'): Promise<MarketAsset | null> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const data = type === 'stock' 
    ? mockStocks.find(stock => stock.symbol === symbol)
    : mockCryptos.find(crypto => crypto.symbol === symbol);
  
  if (!data) return null;
  
  const chartData = generateMockChartData(data.price);
  
  // Calculate mock indicators
  const closePrices = chartData.map(item => item.close);
  const rsiValue = Math.floor(Math.random() * 100);
  const macdValue = Math.random() * 2 - 1;
  const macdSignal = macdValue + (Math.random() * 0.4 - 0.2);
  
  return {
    id: symbol,
    type,
    symbol,
    name: data.name,
    data,
    chartData,
    indicators: {
      rsi: {
        name: 'RSI',
        value: rsiValue,
        status: rsiValue > 70 ? 'overbought' : rsiValue < 30 ? 'oversold' : 'neutral',
      },
      macd: {
        name: 'MACD',
        value: macdValue,
        signal: macdSignal,
        status: macdValue > macdSignal ? 'bullish' : 'bearish',
      },
      movingAverages: {
        ma50: closePrices.slice(-50).reduce((sum, price) => sum + price, 0) / Math.min(50, closePrices.length),
        ma200: closePrices.slice(-200).reduce((sum, price) => sum + price, 0) / Math.min(200, closePrices.length),
      },
    },
  };
};

// Get chart data for an asset
export const getChartData = async (symbol: string, type: 'stock' | 'crypto', timeframe: '1d' | '1w' | '1m' | '3m' | '1y' = '1m'): Promise<ChartData[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 400));
  
  const data = type === 'stock' 
    ? mockStocks.find(stock => stock.symbol === symbol)
    : mockCryptos.find(crypto => crypto.symbol === symbol);
  
  if (!data) return [];
  
  const days = timeframe === '1d' ? 1 
    : timeframe === '1w' ? 7 
    : timeframe === '1m' ? 30 
    : timeframe === '3m' ? 90 
    : 365;
  
  return generateMockChartData(data.price, days);
}; 