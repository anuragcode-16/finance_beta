// Using a simple event emitter implementation instead of importing from 'events'
class SimpleEventEmitter {
  private events: Record<string, Function[]> = {};

  on(event: string, listener: Function): () => void {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(listener);
    
    // Return unsubscribe function
    return () => {
      this.events[event] = this.events[event].filter(l => l !== listener);
    };
  }

  emit(event: string, ...args: any[]): void {
    if (!this.events[event]) return;
    this.events[event].forEach(listener => listener(...args));
  }
}

export interface MarketUpdate {
  symbol: string;
  price: number;
  volume: number;
  bid: number;
  ask: number;
  timestamp: number;
  orderBook?: {
    bids: [number, number][]; // [price, size][]
    asks: [number, number][]; // [price, size][]
  };
}

class WebSocketService extends SimpleEventEmitter {
  private mockInterval: number | null = null;
  private subscriptions: Set<string> = new Set();
  private mockData: Record<string, MarketUpdate> = {
    'AAPL': {
      symbol: 'AAPL',
      price: 175.23,
      volume: 32456789,
      bid: 175.20,
      ask: 175.25,
      timestamp: Date.now(),
    },
    'MSFT': {
      symbol: 'MSFT',
      price: 325.76,
      volume: 15678932,
      bid: 325.70,
      ask: 325.80,
      timestamp: Date.now(),
    },
    'GOOGL': {
      symbol: 'GOOGL',
      price: 142.89,
      volume: 8765432,
      bid: 142.85,
      ask: 142.95,
      timestamp: Date.now(),
    },
    'AMZN': {
      symbol: 'AMZN',
      price: 178.45,
      volume: 12345678,
      bid: 178.40,
      ask: 178.50,
      timestamp: Date.now(),
    },
    'TSLA': {
      symbol: 'TSLA',
      price: 245.67,
      volume: 23456789,
      bid: 245.60,
      ask: 245.75,
      timestamp: Date.now(),
    },
    'BTC': {
      symbol: 'BTC',
      price: 65432.10,
      volume: 987654321,
      bid: 65400.00,
      ask: 65450.00,
      timestamp: Date.now(),
    },
    'ETH': {
      symbol: 'ETH',
      price: 3456.78,
      volume: 456789123,
      bid: 3455.00,
      ask: 3458.00,
      timestamp: Date.now(),
    }
  };

  constructor(private baseUrl: string) {
    super();
    console.log('Using mock WebSocket service');
  }

  connect() {
    console.log('Mock WebSocket connected');
    
    // Start sending mock updates
    this.mockInterval = window.setInterval(() => {
      this.sendMockUpdates();
    }, 5000);
  }

  private sendMockUpdates() {
    // Update prices with small random changes
    Object.keys(this.mockData).forEach(symbol => {
      if (this.subscriptions.size === 0 || this.subscriptions.has(symbol)) {
        const data = this.mockData[symbol];
        
        // Generate a random price change (-1% to +1%)
        const changePercent = (Math.random() * 2 - 1) / 100;
        const newPrice = data.price * (1 + changePercent);
        
        // Update the mock data
        this.mockData[symbol] = {
          ...data,
          price: parseFloat(newPrice.toFixed(2)),
          volume: data.volume + Math.floor(Math.random() * 10000),
          bid: parseFloat((newPrice - 0.05).toFixed(2)),
          ask: parseFloat((newPrice + 0.05).toFixed(2)),
          timestamp: Date.now()
        };
        
        // Emit the update
        this.emit('market-update', this.mockData[symbol]);
      }
    });
  }

  subscribe(symbol: string) {
    this.subscriptions.add(symbol);
    console.log(`Mock subscribed to ${symbol}`);
    
    // Send an immediate update for this symbol
    if (this.mockData[symbol]) {
      setTimeout(() => {
        this.emit('market-update', this.mockData[symbol]);
      }, 100);
    }
  }

  unsubscribe(symbol: string) {
    this.subscriptions.delete(symbol);
    console.log(`Mock unsubscribed from ${symbol}`);
  }

  disconnect() {
    if (this.mockInterval) {
      window.clearInterval(this.mockInterval);
      this.mockInterval = null;
    }
    console.log('Mock WebSocket disconnected');
  }
}

// Create and connect the mock service
export const marketWS = new WebSocketService('mock://api.marketpulse.com/ws');
marketWS.connect(); 