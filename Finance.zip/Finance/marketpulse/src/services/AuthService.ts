import { ethers } from 'ethers';

// API base URL - replace with your actual API URL
const API_URL = 'http://localhost:3000/api';

// Local storage keys
const TOKEN_KEY = 'auth_token';
const USER_KEY = 'user_data';

export interface User {
  id: string;
  address: string;
  username?: string;
  email?: string;
  createdAt: string;
}

class AuthService {
  // Get the current authentication token
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  // Get the current user data
  getCurrentUser(): User | null {
    const userStr = localStorage.getItem(USER_KEY);
    if (userStr) {
      return JSON.parse(userStr);
    }
    return null;
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  // Sign in with Ethereum wallet
  async signInWithEthereum(address: string, signature: string): Promise<User> {
    try {
      const response = await fetch(`${API_URL}/auth/signin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ address, signature }),
      });

      if (!response.ok) {
        throw new Error('Authentication failed');
      }

      const data = await response.json();
      
      // Store token and user data
      localStorage.setItem(TOKEN_KEY, data.token);
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      
      return data.user;
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  }

  // Sign up with Ethereum wallet
  async signUpWithEthereum(address: string, signature: string, userData?: { username?: string, email?: string }): Promise<User> {
    try {
      const response = await fetch(`${API_URL}/auth/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          address, 
          signature,
          ...userData
        }),
      });

      if (!response.ok) {
        throw new Error('Registration failed');
      }

      const data = await response.json();
      
      // Store token and user data
      localStorage.setItem(TOKEN_KEY, data.token);
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      
      return data.user;
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  }

  // Generate a nonce message for signing
  generateNonceMessage(address: string, action: 'signin' | 'signup'): string {
    const timestamp = Date.now();
    return `I am signing this message to ${action === 'signin' ? 'sign in to' : 'register with'} MarketPulse with my Ethereum address: ${address}\nTimestamp: ${timestamp}`;
  }

  // Verify a signature
  verifySignature(message: string, signature: string, address: string): boolean {
    try {
      const recoveredAddress = ethers.utils.verifyMessage(message, signature);
      return recoveredAddress.toLowerCase() === address.toLowerCase();
    } catch (error) {
      console.error('Signature verification error:', error);
      return false;
    }
  }

  // Sign out
  signOut(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }
}

export const authService = new AuthService(); 