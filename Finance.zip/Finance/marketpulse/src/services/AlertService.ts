import { marketWS, MarketUpdate } from './WebSocketService';

// Polyfill for crypto.randomUUID() if not available
const generateUUID = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

const getUUID = (): string => {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return generateUUID();
};

export interface Alert {
  id: string;
  symbol: string;
  type: 'price' | 'volume' | 'indicator';
  condition: 'above' | 'below' | 'crosses';
  value: number;
  notifyVia: ('push' | 'email')[];
  active: boolean;
  createdAt: Date;
}

export interface AlertNotification {
  id: string;
  alertId: string;
  symbol: string;
  message: string;
  timestamp: Date;
  read: boolean;
}

class AlertService {
  private alerts: Map<string, Alert> = new Map();
  private notifications: AlertNotification[] = [];
  private subscribers: Set<(notification: AlertNotification) => void> = new Set();

  constructor() {
    marketWS.on('market-update', this.checkAlerts.bind(this));
    
    // Add some sample alerts
    this.addSampleAlerts();
  }
  
  private addSampleAlerts() {
    // Add a sample price alert for Apple
    this.addAlert({
      symbol: 'AAPL',
      type: 'price',
      condition: 'above',
      value: 180,
      notifyVia: ['push'],
      active: true
    });
    
    // Add a sample volume alert for Bitcoin
    this.addAlert({
      symbol: 'BTC',
      type: 'volume',
      condition: 'above',
      value: 1000000000,
      notifyVia: ['push', 'email'],
      active: true
    });
  }

  addAlert(alert: Omit<Alert, 'id' | 'createdAt'>): Alert {
    const newAlert: Alert = {
      ...alert,
      id: getUUID(),
      createdAt: new Date(),
    };
    this.alerts.set(newAlert.id, newAlert);
    return newAlert;
  }

  removeAlert(id: string) {
    this.alerts.delete(id);
  }

  getAlerts(): Alert[] {
    return Array.from(this.alerts.values());
  }

  toggleAlert(id: string, active: boolean) {
    const alert = this.alerts.get(id);
    if (alert) {
      alert.active = active;
      this.alerts.set(id, alert);
    }
  }

  private checkAlerts(update: MarketUpdate) {
    for (const alert of this.alerts.values()) {
      if (!alert.active || alert.symbol !== update.symbol) continue;

      let triggered = false;
      let value = 0;

      switch (alert.type) {
        case 'price':
          value = update.price;
          triggered = this.evaluateCondition(value, alert.condition, alert.value);
          break;
        case 'volume':
          value = update.volume;
          triggered = this.evaluateCondition(value, alert.condition, alert.value);
          break;
        case 'indicator':
          // Handle indicator alerts based on technical analysis
          break;
      }

      if (triggered) {
        this.createNotification(alert, value);
      }
    }
  }

  private evaluateCondition(current: number, condition: Alert['condition'], threshold: number): boolean {
    switch (condition) {
      case 'above':
        return current > threshold;
      case 'below':
        return current < threshold;
      case 'crosses':
        // Implement crossing logic with historical data
        return false;
      default:
        return false;
    }
  }

  private createNotification(alert: Alert, value: number) {
    const notification: AlertNotification = {
      id: getUUID(),
      alertId: alert.id,
      symbol: alert.symbol,
      message: this.formatAlertMessage(alert, value),
      timestamp: new Date(),
      read: false,
    };

    this.notifications.unshift(notification);
    this.notifySubscribers(notification);

    if (alert.notifyVia.includes('push')) {
      this.sendPushNotification(notification);
    }

    if (alert.notifyVia.includes('email')) {
      this.sendEmailNotification(notification);
    }
  }

  private formatAlertMessage(alert: Alert, value: number): string {
    return `${alert.symbol} ${alert.type} ${alert.condition} ${alert.value} (Current: ${value})`;
  }

  private async sendPushNotification(notification: AlertNotification) {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('MarketPulse Alert', {
        body: notification.message,
        icon: '/logo.png'
      });
    }
  }

  private async sendEmailNotification(notification: AlertNotification) {
    // Implement email notification logic
    console.log('Sending email notification:', notification);
  }

  subscribe(callback: (notification: AlertNotification) => void) {
    this.subscribers.add(callback);
    return () => this.subscribers.delete(callback);
  }

  private notifySubscribers(notification: AlertNotification) {
    this.subscribers.forEach(callback => callback(notification));
  }

  getNotifications(): AlertNotification[] {
    return this.notifications;
  }

  markNotificationAsRead(id: string) {
    const notification = this.notifications.find(n => n.id === id);
    if (notification) {
      notification.read = true;
    }
  }

  clearNotifications() {
    this.notifications = [];
  }
}

export const alertService = new AlertService(); 