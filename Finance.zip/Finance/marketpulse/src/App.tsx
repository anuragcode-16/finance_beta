import { ThemeProvider } from './context/ThemeContext';
import { DashboardProvider } from './context/DashboardContext';
import { Web3Provider } from './context/Web3Context';
import Dashboard from './components/dashboard/Dashboard';
import './App.css';

function App() {
  return (
    <ThemeProvider>
      <Web3Provider>
        <DashboardProvider>
          <Dashboard />
        </DashboardProvider>
      </Web3Provider>
    </ThemeProvider>
  );
}

export default App;
