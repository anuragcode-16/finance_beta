export interface StockData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  lastUpdated: string;
}

export interface CryptoData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  lastUpdated: string;
}

export interface ChartData {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface TechnicalIndicator {
  name: string;
  value: number;
  signal?: number;
  status?: 'bullish' | 'bearish' | 'neutral';
}

export interface MarketAsset {
  id: string;
  type: 'stock' | 'crypto';
  symbol: string;
  name: string;
  data: StockData | CryptoData;
  chartData?: ChartData[];
  indicators?: {
    rsi?: TechnicalIndicator;
    macd?: TechnicalIndicator;
    movingAverages?: {
      ma50: number;
      ma200: number;
    };
  };
}

export interface WidgetConfig {
  id: string;
  type: 'price' | 'chart' | 'indicator' | 'news' | 'alert' | 'portfolio';
  title: string;
  asset?: string;
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  settings?: Record<string, any>;
} 