interface Window {
  ethereum: any;
} 