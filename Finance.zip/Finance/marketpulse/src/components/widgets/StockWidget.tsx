import { Card, Table, Spinner, Badge, Dropdown, OverlayTrigger, Tooltip, Button } from 'react-bootstrap';
import { useStocks } from '../../hooks/useMarketData';
import { FaArrowUp, FaArrowDown, FaEllipsisV, FaSyncAlt, FaStar, FaRegStar, FaFilter, FaSort, FaInfoCircle } from 'react-icons/fa';
import { WidgetConfig } from '../../types/market';
import { useDashboard } from '../../context/DashboardContext';
import { useState } from 'react';

interface StockWidgetProps {
  widget: WidgetConfig;
}

const StockWidget = ({ widget }: StockWidgetProps) => {
  const { stocks, loading, error } = useStocks();
  const { removeWidget } = useDashboard();
  const [favorites, setFavorites] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<string>('symbol');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const formatNumber = (num: number, decimals = 2) => {
    return num.toLocaleString(undefined, { 
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals 
    });
  };

  const formatMarketCap = (marketCap: number) => {
    if (marketCap >= 1e12) {
      return `$${(marketCap / 1e12).toFixed(2)}T`;
    } else if (marketCap >= 1e9) {
      return `$${(marketCap / 1e9).toFixed(2)}B`;
    } else if (marketCap >= 1e6) {
      return `$${(marketCap / 1e6).toFixed(2)}M`;
    } else {
      return `$${marketCap.toLocaleString()}`;
    }
  };

  const toggleFavorite = (symbol: string) => {
    setFavorites(prev => 
      prev.includes(symbol) 
        ? prev.filter(s => s !== symbol) 
        : [...prev, symbol]
    );
  };

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortDirection('asc');
    }
  };

  const sortedStocks = [...stocks].sort((a, b) => {
    let comparison = 0;
    
    switch (sortBy) {
      case 'symbol':
        comparison = a.symbol.localeCompare(b.symbol);
        break;
      case 'name':
        comparison = a.name.localeCompare(b.name);
        break;
      case 'price':
        comparison = a.price - b.price;
        break;
      case 'change':
        comparison = a.change - b.change;
        break;
      case 'marketCap':
        comparison = a.marketCap - b.marketCap;
        break;
      default:
        comparison = 0;
    }
    
    return sortDirection === 'asc' ? comparison : -comparison;
  });

  if (loading) {
    return (
      <div className="widget shadow-md" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
        <div className="widget-header">
          <h3 className="widget-title">{widget.title}</h3>
        </div>
        <div className="widget-body d-flex justify-content-center align-items-center">
          <div className="text-center">
            <Spinner animation="border" role="status" variant="primary" className="mb-3">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
            <p className="text-muted mb-0">Loading stock data...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="widget shadow-md" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
        <div className="widget-header">
          <h3 className="widget-title">{widget.title}</h3>
        </div>
        <div className="widget-body text-center">
          <div className="text-danger mb-3">{error}</div>
          <button className="btn btn-outline-primary">
            <FaSyncAlt className="me-2" /> Retry
          </button>
        </div>
      </div>
    );
  }

  // Calculate market summary
  const marketSummary = {
    gainers: stocks.filter(s => s.change > 0).length,
    losers: stocks.filter(s => s.change < 0).length,
    unchanged: stocks.filter(s => s.change === 0).length,
    averageChange: stocks.reduce((acc, stock) => acc + stock.changePercent, 0) / stocks.length
  };

  return (
    <div className="widget shadow-md" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
      <div className="widget-header">
        <div className="d-flex align-items-center">
          <h3 className="widget-title">{widget.title}</h3>
          <Badge bg="info" className="ms-2" pill>Stocks</Badge>
        </div>
        <div className="d-flex align-items-center">
          <div className="text-muted small me-3 d-flex align-items-center">
            <span className="badge bg-light text-secondary border me-2">
              {stocks.length} stocks
            </span>
            <span>Last updated: {new Date().toLocaleTimeString()}</span>
          </div>
          <div className="d-flex">
            <OverlayTrigger
              placement="top"
              overlay={<Tooltip>Filter stocks</Tooltip>}
            >
              <Button variant="light" size="sm" className="me-2 p-1">
                <FaFilter />
              </Button>
            </OverlayTrigger>
            <Dropdown align="end">
              <Dropdown.Toggle as="div" className="cursor-pointer">
                <FaEllipsisV />
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item>
                  <FaSyncAlt className="me-2" /> Refresh Data
                </Dropdown.Item>
                <Dropdown.Item onClick={() => removeWidget(widget.id)}>
                  Remove Widget
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
      </div>
      
      <div className="p-3 border-bottom bg-body-tertiary">
        <div className="row g-2">
          <div className="col-md-3 col-6">
            <div className="d-flex flex-column">
              <small className="text-muted">Market Summary</small>
              <div className={`fw-bold ${marketSummary.averageChange >= 0 ? 'text-success' : 'text-danger'}`}>
                {marketSummary.averageChange >= 0 ? '+' : ''}{marketSummary.averageChange.toFixed(2)}%
              </div>
            </div>
          </div>
          <div className="col-md-3 col-6">
            <div className="d-flex flex-column">
              <small className="text-muted">Gainers</small>
              <div className="fw-bold text-success">
                {marketSummary.gainers} <small>({((marketSummary.gainers / stocks.length) * 100).toFixed(0)}%)</small>
              </div>
            </div>
          </div>
          <div className="col-md-3 col-6">
            <div className="d-flex flex-column">
              <small className="text-muted">Losers</small>
              <div className="fw-bold text-danger">
                {marketSummary.losers} <small>({((marketSummary.losers / stocks.length) * 100).toFixed(0)}%)</small>
              </div>
            </div>
          </div>
          <div className="col-md-3 col-6">
            <div className="d-flex flex-column">
              <small className="text-muted">Unchanged</small>
              <div className="fw-bold text-secondary">
                {marketSummary.unchanged} <small>({((marketSummary.unchanged / stocks.length) * 100).toFixed(0)}%)</small>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="widget-body no-padding">
        <Table hover responsive className="mb-0">
          <thead>
            <tr>
              <th style={{ width: '40px' }}></th>
              <th className="cursor-pointer" onClick={() => handleSort('symbol')}>
                <div className="d-flex align-items-center">
                  Symbol
                  {sortBy === 'symbol' && (
                    <FaSort className="ms-1" style={{ fontSize: '0.75rem', opacity: 0.7 }} />
                  )}
                </div>
              </th>
              <th className="cursor-pointer" onClick={() => handleSort('name')}>
                <div className="d-flex align-items-center">
                  Name
                  {sortBy === 'name' && (
                    <FaSort className="ms-1" style={{ fontSize: '0.75rem', opacity: 0.7 }} />
                  )}
                </div>
              </th>
              <th className="text-end cursor-pointer" onClick={() => handleSort('price')}>
                <div className="d-flex align-items-center justify-content-end">
                  Price
                  {sortBy === 'price' && (
                    <FaSort className="ms-1" style={{ fontSize: '0.75rem', opacity: 0.7 }} />
                  )}
                </div>
              </th>
              <th className="text-end cursor-pointer" onClick={() => handleSort('change')}>
                <div className="d-flex align-items-center justify-content-end">
                  Change
                  {sortBy === 'change' && (
                    <FaSort className="ms-1" style={{ fontSize: '0.75rem', opacity: 0.7 }} />
                  )}
                </div>
              </th>
              <th className="text-end cursor-pointer" onClick={() => handleSort('marketCap')}>
                <div className="d-flex align-items-center justify-content-end">
                  Market Cap
                  {sortBy === 'marketCap' && (
                    <FaSort className="ms-1" style={{ fontSize: '0.75rem', opacity: 0.7 }} />
                  )}
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            {sortedStocks.map(stock => (
              <tr key={stock.symbol} className="align-middle">
                <td className="text-center">
                  <div 
                    className="cursor-pointer" 
                    onClick={() => toggleFavorite(stock.symbol)}
                  >
                    {favorites.includes(stock.symbol) ? 
                      <FaStar className="text-warning" /> : 
                      <FaRegStar className="text-secondary" />
                    }
                  </div>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    <div className="stock-icon me-2 rounded-circle bg-light d-flex align-items-center justify-content-center" 
                      style={{ width: '32px', height: '32px', fontSize: '12px', fontWeight: 'bold' }}>
                      {stock.symbol.substring(0, 2)}
                    </div>
                    <strong>{stock.symbol}</strong>
                  </div>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    {stock.name}
                    <OverlayTrigger
                      placement="top"
                      overlay={<Tooltip>View company details</Tooltip>}
                    >
                      <div className="ms-2 cursor-pointer text-primary">
                        <FaInfoCircle style={{ fontSize: '0.8rem' }} />
                      </div>
                    </OverlayTrigger>
                  </div>
                </td>
                <td className="text-end fw-semibold">${formatNumber(stock.price)}</td>
                <td className="text-end">
                  <Badge 
                    bg={stock.change >= 0 ? 'success' : 'danger'} 
                    className="d-inline-flex align-items-center"
                    style={{ 
                      opacity: Math.min(0.7 + Math.abs(stock.changePercent) / 10, 1) 
                    }}
                  >
                    {stock.change >= 0 ? <FaArrowUp className="me-1" /> : <FaArrowDown className="me-1" />}
                    {formatNumber(Math.abs(stock.change))} ({formatNumber(Math.abs(stock.changePercent))}%)
                  </Badge>
                </td>
                <td className="text-end">{formatMarketCap(stock.marketCap)}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default StockWidget; 