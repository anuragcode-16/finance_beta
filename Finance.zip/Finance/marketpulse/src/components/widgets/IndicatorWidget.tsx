import { useState } from 'react';
import { Spinner, Form, Table, Badge, Dropdown, Button, OverlayTrigger, Tooltip, Modal } from 'react-bootstrap';
import { useAssetDetails } from '../../hooks/useMarketData';
import { WidgetConfig } from '../../types/market';
import { useDashboard } from '../../context/DashboardContext';
import { 
  FaArrowUp, 
  FaArrowDown, 
  FaMinus, 
  FaEllipsisV, 
  FaSyncAlt, 
  FaChartLine,
  FaExchangeAlt,
  FaInfoCircle,
  FaQuestionCircle
} from 'react-icons/fa';

interface IndicatorWidgetProps {
  widget: WidgetConfig;
}

// Define possible status types
type IndicatorStatus = 'bullish' | 'bearish' | 'neutral' | 'overbought' | 'oversold' | undefined;

const IndicatorWidget = ({ widget }: IndicatorWidgetProps) => {
  const [selectedAsset, setSelectedAsset] = useState<string>(widget.asset || 'AAPL');
  const [assetType, setAssetType] = useState<'stock' | 'crypto'>(
    selectedAsset.length <= 4 ? 'stock' : 'crypto'
  );
  const [showAssetModal, setShowAssetModal] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [activeInfoType, setActiveInfoType] = useState<string>('');
  
  const { asset, loading, error } = useAssetDetails(selectedAsset, assetType);
  const { removeWidget } = useDashboard();

  const handleAssetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newAsset = e.target.value;
    setSelectedAsset(newAsset);
    setAssetType(newAsset.length <= 4 ? 'stock' : 'crypto');
    setShowAssetModal(false);
  };

  const getStatusIcon = (status?: string) => {
    if (!status) return <FaMinus />;
    
    switch (status) {
      case 'bullish':
      case 'overbought':
        return <FaArrowUp className="text-success" />;
      case 'bearish':
      case 'oversold':
        return <FaArrowDown className="text-danger" />;
      default:
        return <FaMinus className="text-warning" />;
    }
  };

  const getStatusBadge = (status?: string) => {
    if (!status) return <Badge bg="secondary">Unknown</Badge>;
    
    switch (status) {
      case 'bullish':
        return <Badge bg="success" className="animate-fade-in">Bullish</Badge>;
      case 'bearish':
        return <Badge bg="danger" className="animate-fade-in">Bearish</Badge>;
      case 'neutral':
        return <Badge bg="warning" className="animate-fade-in">Neutral</Badge>;
      case 'overbought':
        return <Badge bg="danger" className="animate-fade-in">Overbought</Badge>;
      case 'oversold':
        return <Badge bg="success" className="animate-fade-in">Oversold</Badge>;
      default:
        return <Badge bg="secondary" className="animate-fade-in">Unknown</Badge>;
    }
  };

  // Calculate overall signal
  const calculateOverallSignal = (): IndicatorStatus => {
    if (!asset || !asset.indicators) return 'neutral';
    
    let bullishCount = 0;
    let bearishCount = 0;
    
    // RSI
    if (asset.indicators.rsi?.status === 'overbought') bearishCount++;
    else if (asset.indicators.rsi?.status === 'oversold') bullishCount++;
    
    // MACD
    if (asset.indicators.macd?.status === 'bullish') bullishCount++;
    else if (asset.indicators.macd?.status === 'bearish') bearishCount++;
    
    // Moving Averages
    const { ma50, ma200 } = asset.indicators.movingAverages || {};
    
    if (ma50 !== undefined && asset.data.price > ma50) bullishCount++;
    else if (ma50 !== undefined) bearishCount++;
    
    if (ma200 !== undefined && asset.data.price > ma200) bullishCount++;
    else if (ma200 !== undefined) bearishCount++;
    
    if (bullishCount > bearishCount) return 'bullish';
    if (bearishCount > bullishCount) return 'bearish';
    return 'neutral';
  };

  // Helper function to safely check if price is above MA
  const isPriceAboveMA = (maValue?: number) => {
    if (maValue === undefined || !asset) return false;
    return asset.data.price > maValue;
  };

  // Helper to get percentage difference from MA
  const getPercentDiff = (maValue?: number) => {
    if (maValue === undefined || !asset) return 0;
    return ((asset.data.price - maValue) / maValue) * 100;
  };

  const showIndicatorInfo = (type: string) => {
    setActiveInfoType(type);
    setShowInfoModal(true);
  };

  const getIndicatorDescription = () => {
    switch (activeInfoType) {
      case 'rsi':
        return (
          <>
            <h5>Relative Strength Index (RSI)</h5>
            <p>The RSI is a momentum oscillator that measures the speed and change of price movements. It ranges from 0 to 100 and is typically used to identify overbought or oversold conditions.</p>
            <ul>
              <li>RSI above 70: Potentially overbought (bearish signal)</li>
              <li>RSI below 30: Potentially oversold (bullish signal)</li>
              <li>RSI between 30-70: Neutral territory</li>
            </ul>
          </>
        );
      case 'macd':
        return (
          <>
            <h5>Moving Average Convergence Divergence (MACD)</h5>
            <p>MACD is a trend-following momentum indicator that shows the relationship between two moving averages of a security's price.</p>
            <ul>
              <li>MACD above signal line: Bullish signal</li>
              <li>MACD below signal line: Bearish signal</li>
              <li>MACD crossing signal line: Potential trend change</li>
            </ul>
          </>
        );
      case 'ma':
        return (
          <>
            <h5>Moving Averages (MA)</h5>
            <p>Moving averages smooth out price data to create a single flowing line, making it easier to identify the direction of the trend.</p>
            <ul>
              <li>Price above MA: Bullish signal</li>
              <li>Price below MA: Bearish signal</li>
              <li>Short-term MA crosses above long-term MA: Bullish crossover</li>
              <li>Short-term MA crosses below long-term MA: Bearish crossover</li>
            </ul>
          </>
        );
      default:
        return <p>Select an indicator to see more information.</p>;
    }
  };

  const overallSignal = calculateOverallSignal();

  if (loading) {
    return (
      <div className="widget shadow-md" style={{ 
        gridColumn: `span ${widget.position.width}`, 
        gridRow: `span ${widget.position.height}`,
        background: '#1e293b'
      }}>
        <div className="widget-header" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <h3 className="widget-title text-white">{widget.title || 'Technical Indicators'}</h3>
        </div>
        <div className="widget-body d-flex justify-content-center align-items-center">
          <div className="text-center">
            <Spinner animation="border" role="status" variant="primary" className="mb-3">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
            <p className="text-muted mb-0">Loading indicator data...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="widget shadow-md" style={{ 
        gridColumn: `span ${widget.position.width}`, 
        gridRow: `span ${widget.position.height}`,
        background: '#1e293b'
      }}>
        <div className="widget-header" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <h3 className="widget-title text-white">{widget.title || 'Technical Indicators'}</h3>
        </div>
        <div className="widget-body d-flex justify-content-center align-items-center">
          <div className="text-center">
            <div className="mb-3 text-danger">
              <FaExclamationTriangle size={32} />
            </div>
            <h5 className="text-white">Error Loading Data</h5>
            <p className="text-muted">Unable to load indicator data. Please try again later.</p>
            <Button variant="primary" onClick={() => window.location.reload()}>
              <FaSyncAlt className="me-2" /> Refresh
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="widget shadow-md" style={{ 
      gridColumn: `span ${widget.position.width}`, 
      gridRow: `span ${widget.position.height}`,
      background: '#1e293b'
    }}>
      <div className="widget-header d-flex justify-content-between align-items-center" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
        <div className="d-flex align-items-center">
          <h3 className="widget-title text-white">{widget.title || 'Technical Indicators'}</h3>
          <OverlayTrigger
            placement="top"
            overlay={<Tooltip>View indicator explanations</Tooltip>}
          >
            <Button 
              variant="link" 
              className="p-0 ms-2 text-info" 
              onClick={() => showIndicatorInfo('general')}
            >
              <FaInfoCircle />
            </Button>
          </OverlayTrigger>
        </div>
        <div className="d-flex align-items-center">
          <Button 
            variant="outline-light" 
            size="sm" 
            className="me-2 interactive-hover"
            onClick={() => setShowAssetModal(true)}
          >
            <FaExchangeAlt className="me-2" /> Change Asset
          </Button>
          <Dropdown align="end">
            <Dropdown.Toggle as="div" className="cursor-pointer text-white">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item onClick={() => window.location.reload()}>
                <FaSyncAlt className="me-2" /> Refresh Data
              </Dropdown.Item>
              <Dropdown.Item onClick={() => setShowAssetModal(true)}>
                <FaExchangeAlt className="me-2" /> Change Asset
              </Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item onClick={() => removeWidget(widget.id)}>
                Remove Widget
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      <div className="widget-body p-0 scrollable-content">
        {asset && (
          <>
            <div className="p-3" style={{ borderBottom: '1px solid #334155' }}>
              <div className="d-flex justify-content-between align-items-center">
                <div className="d-flex align-items-center">
                  <div className="asset-icon me-3 rounded-circle bg-dark d-flex align-items-center justify-content-center interactive-hover" 
                    style={{ width: '48px', height: '48px', fontSize: '18px', fontWeight: 'bold', color: 'white' }}>
                    {selectedAsset.substring(0, 2)}
                  </div>
                  <div>
                    <h5 className="mb-0 text-white">{asset.name} <span className="text-secondary">({asset.symbol})</span></h5>
                    <div className="text-muted small">
                      Current Price: <span className="fw-semibold text-white">${asset.data.price.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                <div className="text-center">
                  <h5 className="mb-1 text-white">Overall Signal</h5>
                  <Badge 
                    bg={
                      overallSignal === 'bullish' ? 'success' : 
                      overallSignal === 'bearish' ? 'danger' : 
                      'warning'
                    }
                    className="px-3 py-2 animate-fade-in"
                    style={{ 
                      fontSize: '1rem',
                      background: overallSignal === 'bullish' ? '#22c55e' : 
                                 overallSignal === 'bearish' ? '#ef4444' : 
                                 '#facc15',
                    }}
                  >
                    {getStatusIcon(overallSignal)}{' '}
                    {overallSignal === 'bullish' ? 'Bullish' : 
                     overallSignal === 'bearish' ? 'Bearish' : 
                     'Neutral'}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="p-3 indicator-cards">
              {/* RSI Card */}
              <div className="border p-3 mb-3 interactive-hover" style={{ borderRadius: '12px', borderColor: '#334155' }}>
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="text-white mb-0 d-flex align-items-center">
                    RSI
                    <OverlayTrigger
                      placement="top"
                      overlay={<Tooltip>Relative Strength Index</Tooltip>}
                    >
                      <Button 
                        variant="link" 
                        className="p-0 ms-2 text-info" 
                        style={{ fontSize: '0.8rem' }}
                        onClick={() => showIndicatorInfo('rsi')}
                      >
                        <FaQuestionCircle />
                      </Button>
                    </OverlayTrigger>
                  </h6>
                  {asset.indicators?.rsi && getStatusBadge(asset.indicators.rsi.status)}
                </div>
                
                <div className="mb-2">
                  <div className="d-flex justify-content-between mb-1">
                    <small className="text-muted">0</small>
                    <small className="text-muted">30</small>
                    <small className="text-muted">70</small>
                    <small className="text-muted">100</small>
                  </div>
                  <div className="progress" style={{ height: '8px' }}>
                    <div 
                      className="progress-bar" 
                      role="progressbar" 
                      style={{ 
                        width: `${asset.indicators?.rsi?.value || 0}%`,
                        background: asset.indicators?.rsi?.status === 'overbought' ? '#ef4444' : 
                                   asset.indicators?.rsi?.status === 'oversold' ? '#22c55e' : 
                                   '#3b82f6'
                      }}
                      aria-valuenow={asset.indicators?.rsi?.value || 0}
                      aria-valuemin={0}
                      aria-valuemax={100}
                    ></div>
                  </div>
                </div>
                
                <div className="text-center">
                  <h4 className="mb-0 text-white">{asset.indicators?.rsi?.value.toFixed(1)}</h4>
                  <small className="text-muted">
                    {asset.indicators?.rsi?.status === 'overbought' ? 'Potentially overbought' : 
                     asset.indicators?.rsi?.status === 'oversold' ? 'Potentially oversold' : 
                     'Neutral territory'}
                  </small>
                </div>
              </div>
              
              {/* MACD Card */}
              <div className="border p-3 mb-3 interactive-hover" style={{ borderRadius: '12px', borderColor: '#334155' }}>
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="text-white mb-0 d-flex align-items-center">
                    MACD
                    <OverlayTrigger
                      placement="top"
                      overlay={<Tooltip>Moving Average Convergence Divergence</Tooltip>}
                    >
                      <Button 
                        variant="link" 
                        className="p-0 ms-2 text-info" 
                        style={{ fontSize: '0.8rem' }}
                        onClick={() => showIndicatorInfo('macd')}
                      >
                        <FaQuestionCircle />
                      </Button>
                    </OverlayTrigger>
                  </h6>
                  {asset.indicators?.macd && getStatusBadge(asset.indicators.macd.status)}
                </div>
                
                <div className="d-flex align-items-center justify-content-center mb-2">
                  <div className="d-flex align-items-center">
                    <div 
                      className="me-2" 
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        borderRadius: '50%', 
                        background: asset.indicators?.macd?.value && asset.indicators?.macd?.value > 0 ? '#22c55e' : '#ef4444',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        fontSize: '1.2rem'
                      }}
                    >
                      {asset.indicators?.macd?.value && asset.indicators?.macd?.value > 0 ? <FaArrowUp /> : <FaArrowDown />}
                    </div>
                    <div>
                      <div className="text-white">
                        {asset.indicators?.macd?.value.toFixed(2)}
                      </div>
                      <small className="text-muted">MACD Line</small>
                    </div>
                  </div>
                  
                  <div className="mx-3 text-muted">vs</div>
                  
                  <div className="d-flex align-items-center">
                    <div 
                      className="me-2" 
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        borderRadius: '50%', 
                        background: '#3b82f6',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        fontSize: '1.2rem'
                      }}
                    >
                      <FaChartLine />
                    </div>
                    <div>
                      <div className="text-white">
                        {asset.indicators?.macd?.signal.toFixed(2)}
                      </div>
                      <small className="text-muted">Signal Line</small>
                    </div>
                  </div>
                </div>
                
                <div className="text-center">
                  <small className="text-muted">
                    {asset.indicators?.macd?.status === 'bullish' ? 'MACD above signal line (Bullish)' : 
                     'MACD below signal line (Bearish)'}
                  </small>
                </div>
              </div>
              
              {/* Moving Averages Card */}
              <div className="border p-3 mb-3 interactive-hover" style={{ borderRadius: '12px', borderColor: '#334155' }}>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h6 className="text-white mb-0 d-flex align-items-center">
                    Moving Averages
                    <OverlayTrigger
                      placement="top"
                      overlay={<Tooltip>Price relative to moving averages</Tooltip>}
                    >
                      <Button 
                        variant="link" 
                        className="p-0 ms-2 text-info" 
                        style={{ fontSize: '0.8rem' }}
                        onClick={() => showIndicatorInfo('ma')}
                      >
                        <FaQuestionCircle />
                      </Button>
                    </OverlayTrigger>
                  </h6>
                </div>
                
                <div className="mb-3">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <div>
                      <Badge bg="primary" className="me-2">MA50</Badge>
                      <span className="text-white">${asset.indicators?.movingAverages?.ma50.toFixed(2)}</span>
                    </div>
                    <Badge 
                      bg={isPriceAboveMA(asset.indicators?.movingAverages?.ma50) ? 'success' : 'danger'}
                      className="animate-fade-in"
                    >
                      {isPriceAboveMA(asset.indicators?.movingAverages?.ma50) ? 
                        <><FaArrowUp className="me-1" /> Above</> : 
                        <><FaArrowDown className="me-1" /> Below</>
                      }
                      <span className="ms-1">
                        ({Math.abs(getPercentDiff(asset.indicators?.movingAverages?.ma50)).toFixed(2)}%)
                      </span>
                    </Badge>
                  </div>
                  
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <Badge bg="secondary" className="me-2">MA200</Badge>
                      <span className="text-white">${asset.indicators?.movingAverages?.ma200.toFixed(2)}</span>
                    </div>
                    <Badge 
                      bg={isPriceAboveMA(asset.indicators?.movingAverages?.ma200) ? 'success' : 'danger'}
                      className="animate-fade-in"
                    >
                      {isPriceAboveMA(asset.indicators?.movingAverages?.ma200) ? 
                        <><FaArrowUp className="me-1" /> Above</> : 
                        <><FaArrowDown className="me-1" /> Below</>
                      }
                      <span className="ms-1">
                        ({Math.abs(getPercentDiff(asset.indicators?.movingAverages?.ma200)).toFixed(2)}%)
                      </span>
                    </Badge>
                  </div>
                </div>
                
                <div className="text-center">
                  <small className="text-muted">
                    {isPriceAboveMA(asset.indicators?.movingAverages?.ma50) && isPriceAboveMA(asset.indicators?.movingAverages?.ma200) ? 
                      'Price above both MAs (Strong Bullish)' : 
                      !isPriceAboveMA(asset.indicators?.movingAverages?.ma50) && !isPriceAboveMA(asset.indicators?.movingAverages?.ma200) ? 
                      'Price below both MAs (Strong Bearish)' : 
                      isPriceAboveMA(asset.indicators?.movingAverages?.ma50) ? 
                      'Price above MA50 but below MA200 (Mixed)' : 
                      'Price below MA50 but above MA200 (Mixed)'}
                  </small>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Asset Selection Modal */}
      <Modal 
        show={showAssetModal} 
        onHide={() => setShowAssetModal(false)}
        centered
        contentClassName="bg-dark text-white"
      >
        <Modal.Header closeButton style={{ borderBottom: '1px solid #334155' }}>
          <Modal.Title>Change Asset</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group className="mb-3">
            <Form.Label>Select Asset</Form.Label>
            <Form.Select 
              value={selectedAsset}
              onChange={handleAssetChange}
              style={{ background: '#1e293b', color: 'white', border: '1px solid #334155' }}
            >
              <optgroup label="Stocks">
                <option value="AAPL">AAPL - Apple Inc.</option>
                <option value="MSFT">MSFT - Microsoft Corporation</option>
                <option value="GOOGL">GOOGL - Alphabet Inc.</option>
                <option value="AMZN">AMZN - Amazon.com Inc.</option>
                <option value="TSLA">TSLA - Tesla, Inc.</option>
              </optgroup>
              <optgroup label="Cryptocurrencies">
                <option value="BTC">BTC - Bitcoin</option>
                <option value="ETH">ETH - Ethereum</option>
                <option value="SOL">SOL - Solana</option>
                <option value="ADA">ADA - Cardano</option>
                <option value="XRP">XRP - XRP</option>
              </optgroup>
            </Form.Select>
          </Form.Group>
        </Modal.Body>
        <Modal.Footer style={{ borderTop: '1px solid #334155' }}>
          <Button variant="secondary" onClick={() => setShowAssetModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={() => setShowAssetModal(false)}>
            Apply
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Indicator Info Modal */}
      <Modal 
        show={showInfoModal} 
        onHide={() => setShowInfoModal(false)}
        centered
        contentClassName="bg-dark text-white"
      >
        <Modal.Header closeButton style={{ borderBottom: '1px solid #334155' }}>
          <Modal.Title>Technical Indicator Information</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {getIndicatorDescription()}
        </Modal.Body>
        <Modal.Footer style={{ borderTop: '1px solid #334155' }}>
          <Button variant="primary" onClick={() => setShowInfoModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default IndicatorWidget; 