import { Table, Spinner, Badge, Dropdown } from 'react-bootstrap';
import { useCryptos } from '../../hooks/useMarketData';
import { FaArrowUp, FaArrowDown, FaEllipsisV, FaSyncAlt, FaStar, FaRegStar, FaBitcoin } from 'react-icons/fa';
import { WidgetConfig } from '../../types/market';
import { useDashboard } from '../../context/DashboardContext';
import { useState } from 'react';

interface CryptoWidgetProps {
  widget: WidgetConfig;
}

const CryptoWidget = ({ widget }: CryptoWidgetProps) => {
  const { cryptos, loading, error } = useCryptos();
  const { removeWidget } = useDashboard();
  const [favorites, setFavorites] = useState<string[]>([]);

  const formatNumber = (num: number, decimals = 2) => {
    return num.toLocaleString(undefined, { 
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals 
    });
  };

  const formatPrice = (price: number) => {
    if (price < 1) {
      return `$${price.toFixed(4)}`;
    } else if (price < 10) {
      return `$${price.toFixed(3)}`;
    } else {
      return `$${formatNumber(price)}`;
    }
  };

  const formatMarketCap = (marketCap: number) => {
    if (marketCap >= 1e12) {
      return `$${(marketCap / 1e12).toFixed(2)}T`;
    } else if (marketCap >= 1e9) {
      return `$${(marketCap / 1e9).toFixed(2)}B`;
    } else if (marketCap >= 1e6) {
      return `$${(marketCap / 1e6).toFixed(2)}M`;
    } else {
      return `$${marketCap.toLocaleString()}`;
    }
  };

  const toggleFavorite = (symbol: string) => {
    setFavorites(prev => 
      prev.includes(symbol) 
        ? prev.filter(s => s !== symbol) 
        : [...prev, symbol]
    );
  };

  if (loading) {
    return (
      <div className="widget shadow-md" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
        <div className="widget-header">
          <h3 className="widget-title">{widget.title}</h3>
        </div>
        <div className="widget-body d-flex justify-content-center align-items-center">
          <div className="text-center">
            <Spinner animation="border" role="status" variant="primary" className="mb-3">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
            <p className="text-muted mb-0">Loading crypto data...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="widget shadow-md" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
        <div className="widget-header">
          <h3 className="widget-title">{widget.title}</h3>
        </div>
        <div className="widget-body text-center">
          <div className="text-danger mb-3">{error}</div>
          <button className="btn btn-outline-primary">
            <FaSyncAlt className="me-2" /> Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="widget shadow-md" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
      <div className="widget-header">
        <div className="d-flex align-items-center">
          <h3 className="widget-title">{widget.title}</h3>
          <Badge bg="warning" className="ms-2" pill>Crypto</Badge>
        </div>
        <div className="d-flex align-items-center">
          <div className="text-muted small me-3 d-flex align-items-center">
            <span className="badge bg-light text-secondary border me-2">
              {cryptos.length} coins
            </span>
            Last updated: {new Date().toLocaleTimeString()}
          </div>
          <Dropdown align="end">
            <Dropdown.Toggle as="div" className="cursor-pointer">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item>
                <FaSyncAlt className="me-2" /> Refresh Data
              </Dropdown.Item>
              <Dropdown.Item onClick={() => removeWidget(widget.id)}>
                Remove Widget
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      <div className="widget-body no-padding">
        <Table hover responsive className="mb-0">
          <thead>
            <tr>
              <th style={{ width: '40px' }}></th>
              <th>Symbol</th>
              <th>Name</th>
              <th className="text-end">Price</th>
              <th className="text-end">Change</th>
              <th className="text-end">Market Cap</th>
            </tr>
          </thead>
          <tbody>
            {cryptos.map(crypto => (
              <tr key={crypto.symbol} className="align-middle">
                <td className="text-center">
                  <div 
                    className="cursor-pointer" 
                    onClick={() => toggleFavorite(crypto.symbol)}
                  >
                    {favorites.includes(crypto.symbol) ? 
                      <FaStar className="text-warning" /> : 
                      <FaRegStar className="text-secondary" />
                    }
                  </div>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    <div className="crypto-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
                      style={{ 
                        width: '32px', 
                        height: '32px', 
                        fontSize: '16px', 
                        background: 'rgba(247, 147, 26, 0.15)', 
                        color: '#f7931a' 
                      }}>
                      <FaBitcoin />
                    </div>
                    <strong>{crypto.symbol}</strong>
                  </div>
                </td>
                <td>{crypto.name}</td>
                <td className="text-end fw-semibold">{formatPrice(crypto.price)}</td>
                <td className="text-end">
                  <Badge 
                    bg={crypto.change >= 0 ? 'success' : 'danger'} 
                    className="d-inline-flex align-items-center"
                    style={{ 
                      opacity: Math.min(0.7 + Math.abs(crypto.changePercent) / 10, 1) 
                    }}
                  >
                    {crypto.change >= 0 ? <FaArrowUp className="me-1" /> : <FaArrowDown className="me-1" />}
                    {formatNumber(Math.abs(crypto.change))} ({formatNumber(Math.abs(crypto.changePercent))}%)
                  </Badge>
                </td>
                <td className="text-end">{formatMarketCap(crypto.marketCap)}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default CryptoWidget; 