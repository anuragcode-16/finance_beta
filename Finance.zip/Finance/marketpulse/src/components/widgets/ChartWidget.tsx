import { useState, useEffect } from 'react';
import { Spinner, ButtonGroup, Button, Form, Dropdown, Badge, Modal, OverlayTrigger, Tooltip, Table } from 'react-bootstrap';
import { useChartData, useAssetDetails } from '../../hooks/useMarketData';
import { WidgetConfig } from '../../types/market';
import { useDashboard } from '../../context/DashboardContext';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend,
  ReferenceLine,
  BarChart,
  Bar,
  ComposedChart,
  Line
} from 'recharts';
import { 
  FaEllipsisV, 
  FaArrowUp, 
  FaArrowDown, 
  FaSyncAlt, 
  FaChartLine, 
  FaChartBar,
  FaExchangeAlt,
  FaInfoCircle,
  FaRegStar,
  FaStar,
  FaExclamationTriangle,
  FaSearch,
  FaPlus,
  FaCalendarAlt,
  FaBolt,
  FaChevronRight,
  FaEraser,
  FaEye,
  FaTrash,
  FaBell,
  FaStepBackward,
  FaSave,
  FaMousePointer,
  FaCrosshairs,
  FaDrawPolygon,
  FaFont,
  FaRuler,
  FaPaintBrush
} from 'react-icons/fa';

interface ChartWidgetProps {
  widget: WidgetConfig;
}

interface CryptoListing {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume24h: number;
  marketCap: number;
}

type TimeframeType = '1d' | '1w' | '1m' | '3m' | '1y';
type ChartType = 'area' | 'candle' | 'composed';

const ChartWidget = ({ widget }: ChartWidgetProps) => {
  const [timeframe, setTimeframe] = useState<TimeframeType>(
    (widget.settings?.timeframe as TimeframeType) || '1m'
  );
  const [chartType, setChartType] = useState<ChartType>('area');
  const [showAssetModal, setShowAssetModal] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<string>(widget.asset || 'BTC');
  const [assetType, setAssetType] = useState<'stock' | 'crypto'>(
    selectedAsset.length <= 4 ? 'stock' : 'crypto'
  );
  const [isFavorite, setIsFavorite] = useState(false);
  const [showTechnicalOverlay, setShowTechnicalOverlay] = useState(false);
  const [showListings, setShowListings] = useState(false);
  const [cryptoListings, setCryptoListings] = useState<CryptoListing[]>([]);
  const [listingsLoading, setListingsLoading] = useState(false);
  const [priceChangeMap, setPriceChangeMap] = useState<Record<string, 'up' | 'down' | null>>({});
  
  // Add new state variables for TradingView-like features
  const [showBuySellPanel, setShowBuySellPanel] = useState(true);
  const [showVolumeTicks, setShowVolumeTicks] = useState(true);
  const [showWatchlist, setShowWatchlist] = useState(true);
  const [indicatorsOpen, setIndicatorsOpen] = useState(false);
  const [timeframeOptions] = useState(['1D', '5D', '1M', '3M', '6M', 'YTD', '1Y', '5Y', 'All']);
  const [watchlistItems] = useState([
    { symbol: 'SPX', name: 'S&P 500', price: 5638.93, change: 117.40, changePercent: 2.13, color: '#f00' },
    { symbol: 'NDQ', name: 'NASDAQ', price: 19704.64, change: 479.15, changePercent: 2.49, color: '#0cf' },
    { symbol: 'DJI', name: 'Dow Jones', price: 41488.19, change: 674.62, changePercent: 1.65, color: '#0cf' },
    { symbol: 'VIX', name: 'Volatility Index', price: 21.77, change: -2.89, changePercent: -11.72, color: '#0f0' },
    { symbol: 'DXY', name: 'US Dollar Index', price: 103.734, change: -0.099, changePercent: -0.10, color: '#0cf' },
    { symbol: 'AAPL', name: 'Apple Inc.', price: 213.49, change: 3.81, changePercent: 1.82, color: '#000' },
  ]);
  
  const { asset } = useAssetDetails(selectedAsset, assetType);
  const { chartData, loading, error } = useChartData(selectedAsset, assetType, timeframe);
  const { removeWidget } = useDashboard();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: assetType === 'crypto' ? 2 : 2,
      maximumFractionDigits: assetType === 'crypto' ? 2 : 2
    }).format(price);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString();
  };

  const handleAssetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newAsset = e.target.value;
    setSelectedAsset(newAsset);
    setAssetType(newAsset.length <= 4 ? 'stock' : 'crypto');
  };

  const customTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="custom-tooltip animate-fade-in">
          <p className="mb-1 fw-bold">{formatDate(label)}</p>
          <div className="d-flex justify-content-between mb-1">
            <span className="text-secondary">Open:</span>
            <span className="fw-semibold">{formatPrice(payload[0].payload.open)}</span>
          </div>
          <div className="d-flex justify-content-between mb-1">
            <span className="text-secondary">High:</span>
            <span className="fw-semibold text-success">{formatPrice(payload[0].payload.high)}</span>
          </div>
          <div className="d-flex justify-content-between mb-1">
            <span className="text-secondary">Low:</span>
            <span className="fw-semibold text-danger">{formatPrice(payload[0].payload.low)}</span>
          </div>
          <div className="d-flex justify-content-between mb-1">
            <span className="text-secondary">Close:</span>
            <span className="fw-semibold">{formatPrice(payload[0].payload.close)}</span>
          </div>
          <div className="d-flex justify-content-between mb-0">
            <span className="text-secondary">Volume:</span>
            <span className="fw-semibold">{payload[0].payload.volume.toLocaleString()}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  // Fetch crypto listings
  useEffect(() => {
    if (showListings) {
      setListingsLoading(true);
      // Mock data - in a real app, this would be an API call
      setTimeout(() => {
        setCryptoListings([
          { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin', price: 68423.52, change24h: 2.34, volume24h: 28945123456, marketCap: 1345678901234 },
          { id: 'ethereum', symbol: 'ETH', name: 'Ethereum', price: 3521.67, change24h: 1.56, volume24h: 15678234567, marketCap: 423456789012 },
          { id: 'solana', symbol: 'SOL', name: 'Solana', price: 142.89, change24h: 5.23, volume24h: 5678234567, marketCap: 62345678901 },
          { id: 'cardano', symbol: 'ADA', name: 'Cardano', price: 0.45, change24h: -1.23, volume24h: 1234567890, marketCap: 15678901234 },
          { id: 'ripple', symbol: 'XRP', name: 'XRP', price: 0.56, change24h: -0.78, volume24h: 2345678901, marketCap: 28901234567 },
          { id: 'polkadot', symbol: 'DOT', name: 'Polkadot', price: 6.78, change24h: 3.45, volume24h: 987654321, marketCap: 7890123456 },
          { id: 'dogecoin', symbol: 'DOGE', name: 'Dogecoin', price: 0.12, change24h: 8.90, volume24h: 3456789012, marketCap: 16789012345 },
          { id: 'avalanche', symbol: 'AVAX', name: 'Avalanche', price: 34.56, change24h: 4.32, volume24h: 876543210, marketCap: 12345678901 },
          { id: 'chainlink', symbol: 'LINK', name: 'Chainlink', price: 14.32, change24h: 2.10, volume24h: 765432109, marketCap: 8765432109 },
          { id: 'polygon', symbol: 'MATIC', name: 'Polygon', price: 0.67, change24h: -2.45, volume24h: 654321098, marketCap: 6543210987 }
        ]);
        setListingsLoading(false);
      }, 500);
    }
  }, [showListings]);

  // Simulate price updates every 10 seconds
  useEffect(() => {
    if (!showListings || cryptoListings.length === 0) return;
    
    const interval = setInterval(() => {
      const newPriceChangeMap: Record<string, 'up' | 'down' | null> = {};
      
      setCryptoListings(prevListings => 
        prevListings.map(crypto => {
          // Random price change between -1% and +1%
          const changePercent = (Math.random() * 2 - 1) * 0.01;
          const newPrice = crypto.price * (1 + changePercent);
          
          // Record price direction for animation
          newPriceChangeMap[crypto.id] = changePercent > 0 ? 'up' : 'down';
          
          return {
            ...crypto,
            price: newPrice,
            // Slightly adjust 24h change too
            change24h: crypto.change24h + (changePercent * 100) / 4
          };
        })
      );
      
      setPriceChangeMap(newPriceChangeMap);
      
      // Clear animations after 1 second
      setTimeout(() => {
        setPriceChangeMap({});
      }, 1000);
      
    }, 10000);
    
    return () => clearInterval(interval);
  }, [showListings, cryptoListings.length]);

  // Handle crypto selection
  const handleCryptoSelect = (crypto: CryptoListing) => {
    setSelectedAsset(crypto.symbol);
    setAssetType('crypto');
    
    // Optional: close listings after selection
    // setShowListings(false);
  };

  // Format large numbers
  const formatLargeNumber = (num: number) => {
    if (num >= 1000000000000) {
      return `$${(num / 1000000000000).toFixed(2)}T`;
    } else if (num >= 1000000000) {
      return `$${(num / 1000000000).toFixed(2)}B`;
    } else if (num >= 1000000) {
      return `$${(num / 1000000).toFixed(2)}M`;
    } else {
      return `$${num.toLocaleString()}`;
    }
  };

  // Add buy/sell price calculation
  const currentPrice = asset?.data?.price || 0;
  const buyPrice = (currentPrice * 1.001).toFixed(3);
  const sellPrice = (currentPrice * 0.999).toFixed(3);

  if (loading) {
    return (
      <div className="widget shadow-md" style={{ 
        gridColumn: `span ${widget.position.width}`, 
        gridRow: `span ${widget.position.height}`,
        background: '#1e293b'
      }}>
        <div className="widget-header" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <h3 className="widget-title text-white">{widget.title || 'Price Chart'}</h3>
        </div>
        <div className="widget-body d-flex justify-content-center align-items-center" style={{ height: '300px' }}>
          <div className="text-center">
            <Spinner animation="border" role="status" variant="primary" className="mb-3">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
            <p className="text-muted mb-0">Loading chart data...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="widget shadow-md" style={{ 
        gridColumn: `span ${widget.position.width}`, 
        gridRow: `span ${widget.position.height}`,
        background: '#1e293b'
      }}>
        <div className="widget-header" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <h3 className="widget-title text-white">{widget.title || 'Price Chart'}</h3>
        </div>
        <div className="widget-body text-center" style={{ height: '300px' }}>
          <div className="d-flex flex-column justify-content-center align-items-center h-100">
            <div className="text-danger mb-3">
              <FaExclamationTriangle size={32} />
            </div>
            <h5 className="text-white">Error Loading Data</h5>
            <p className="text-muted">{error}</p>
            <Button variant="primary" onClick={() => window.location.reload()}>
              <FaSyncAlt className="me-2" /> Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Calculate price change for the selected timeframe
  const priceChange = chartData.length > 1 
    ? chartData[chartData.length - 1].close - chartData[0].close 
    : 0;
  
  const priceChangePercent = chartData.length > 1 
    ? (priceChange / chartData[0].close) * 100 
    : 0;

  // Calculate moving averages for technical overlay
  const calculateMA = (data: any[], days: number) => {
    return data.map((entry, index) => {
      if (index < days - 1) {
        return { ...entry, [`ma${days}`]: null };
      }
      
      const sum = data
        .slice(index - days + 1, index + 1)
        .reduce((total, item) => total + item.close, 0);
      
      return { ...entry, [`ma${days}`]: sum / days };
    });
  };

  const dataWithMA = showTechnicalOverlay ? calculateMA(calculateMA(chartData, 20), 50) : chartData;

  return (
    <div className="widget shadow-md" style={{ 
      gridColumn: `span ${widget.position.width}`, 
      gridRow: `span ${widget.position.height}`,
      background: '#1e293b'
    }}>
      <div className="widget-header d-flex justify-content-between align-items-center" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
        <div className="d-flex align-items-center">
          <h3 className="widget-title text-white">{widget.title || 'Price Chart'}</h3>
          <Badge 
            bg={priceChangePercent >= 0 ? "success" : "danger"} 
            className="ms-2" 
            pill
          >
            {priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(2)}%
          </Badge>
        </div>
        <div className="d-flex align-items-center">
          <div 
            className="me-3 cursor-pointer interactive-hover"
            onClick={() => setIsFavorite(!isFavorite)}
          >
            {isFavorite ? 
              <FaStar className="text-warning" /> : 
              <FaRegStar className="text-secondary" />
            }
          </div>
          <div 
            className="me-3 cursor-pointer interactive-hover"
            onClick={() => setShowAssetModal(true)}
          >
            <FaExchangeAlt className="text-secondary" />
          </div>
          <Dropdown align="end">
            <Dropdown.Toggle as="div" className="cursor-pointer text-white">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item onClick={() => setShowTechnicalOverlay(!showTechnicalOverlay)}>
                {showTechnicalOverlay ? 'Hide Technical Overlay' : 'Show Technical Overlay'}
              </Dropdown.Item>
              <Dropdown.Item onClick={() => setChartType(chartType === 'area' ? 'candle' : 'area')}>
                {chartType === 'area' ? 'Switch to Candlestick' : 'Switch to Area Chart'}
              </Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item onClick={() => removeWidget(widget.id)}>
                Remove Widget
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      
      <div className="widget-body">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <div className="d-flex align-items-center">
            <div className="asset-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
              style={{ 
                width: '32px', 
                height: '32px', 
                fontSize: '16px', 
                background: assetType === 'crypto' ? 'rgba(247, 147, 26, 0.15)' : 'rgba(59, 130, 246, 0.15)', 
                color: assetType === 'crypto' ? '#f7931a' : '#3b82f6' 
              }}>
              {selectedAsset.substring(0, 1)}
            </div>
            <div>
              <h5 className="mb-0 text-white">{selectedAsset}</h5>
              <small className="text-muted">{assetType === 'crypto' ? 'Cryptocurrency' : 'Stock'}</small>
            </div>
          </div>
          
          <div className="text-end">
            <h5 className="mb-0 text-white">{formatPrice(asset?.data?.price || 0)}</h5>
            <small className={priceChangePercent >= 0 ? "text-success" : "text-danger"}>
              {priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(2)}% ({priceChange >= 0 ? '+' : ''}{formatPrice(priceChange)})
            </small>
          </div>
        </div>
        
        <div className="mb-3">
          <ButtonGroup size="sm">
            <Button 
              variant={timeframe === '1d' ? "primary" : "outline-secondary"} 
              onClick={() => setTimeframe('1d')}
            >
              1D
            </Button>
            <Button 
              variant={timeframe === '1w' ? "primary" : "outline-secondary"} 
              onClick={() => setTimeframe('1w')}
            >
              1W
            </Button>
            <Button 
              variant={timeframe === '1m' ? "primary" : "outline-secondary"} 
              onClick={() => setTimeframe('1m')}
            >
              1M
            </Button>
            <Button 
              variant={timeframe === '3m' ? "primary" : "outline-secondary"} 
              onClick={() => setTimeframe('3m')}
            >
              3M
            </Button>
            <Button 
              variant={timeframe === '1y' ? "primary" : "outline-secondary"} 
              onClick={() => setTimeframe('1y')}
            >
              1Y
            </Button>
          </ButtonGroup>
          
          <ButtonGroup size="sm" className="ms-2">
            <Button 
              variant={chartType === 'area' ? "primary" : "outline-secondary"} 
              onClick={() => setChartType('area')}
            >
              <FaChartLine />
            </Button>
            <Button 
              variant={chartType === 'candle' ? "primary" : "outline-secondary"} 
              onClick={() => setChartType('candle')}
            >
              <FaChartBar />
            </Button>
          </ButtonGroup>
        </div>
        
        <div style={{ height: '300px' }}>
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'area' ? (
              <AreaChart
                data={dataWithMA}
                margin={{ top: 10, right: 10, left: 10, bottom: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={(tick) => {
                    const date = new Date(tick);
                    return timeframe === '1d' ? date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : date.toLocaleDateString([], {month: 'short', day: 'numeric'});
                  }}
                  stroke="#94a3b8"
                  tick={{ fontSize: 12 }}
                />
                <YAxis 
                  domain={['auto', 'auto']}
                  tickFormatter={(tick) => formatPrice(tick)}
                  stroke="#94a3b8"
                  tick={{ fontSize: 12 }}
                  width={80}
                />
                <RechartsTooltip content={customTooltip} />
                <ReferenceLine y={chartData[0]?.close} stroke="#64748b" strokeDasharray="3 3" />
                <Area 
                  type="monotone" 
                  dataKey="close" 
                  stroke="#3b82f6" 
                  fill="url(#colorClose)" 
                  fillOpacity={0.3}
                  name="Price" 
                />
                {showTechnicalOverlay && (
                  <>
                    <Line 
                      type="monotone" 
                      dataKey="ma20" 
                      stroke="#22c55e" 
                      dot={false} 
                      name="MA20" 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="ma50" 
                      stroke="#f59e0b" 
                      dot={false} 
                      name="MA50" 
                    />
                  </>
                )}
                <Legend />
                <defs>
                  <linearGradient id="colorClose" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
              </AreaChart>
            ) : (
              <ComposedChart
                data={dataWithMA}
                margin={{ top: 10, right: 10, left: 10, bottom: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={(tick) => {
                    const date = new Date(tick);
                    return timeframe === '1d' ? date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : date.toLocaleDateString([], {month: 'short', day: 'numeric'});
                  }}
                  stroke="#94a3b8"
                  tick={{ fontSize: 12 }}
                />
                <YAxis 
                  domain={['auto', 'auto']}
                  tickFormatter={(tick) => formatPrice(tick)}
                  stroke="#94a3b8"
                  tick={{ fontSize: 12 }}
                  width={80}
                />
                <RechartsTooltip content={customTooltip} />
                <ReferenceLine y={chartData[0]?.close} stroke="#64748b" strokeDasharray="3 3" />
                {chartData.map((entry, index) => (
                  <rect
                    key={`candle-${index}`}
                    x={index * (100 / chartData.length) + '%'}
                    y={entry.open < entry.close ? entry.close : entry.open}
                    width={(100 / chartData.length) * 0.8 + '%'}
                    height={Math.abs(entry.close - entry.open)}
                    fill={entry.open < entry.close ? '#22c55e' : '#ef4444'}
                  />
                ))}
                {showTechnicalOverlay && (
                  <>
                    <Line 
                      type="monotone" 
                      dataKey="ma20" 
                      stroke="#22c55e" 
                      dot={false} 
                      name="MA20" 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="ma50" 
                      stroke="#f59e0b" 
                      dot={false} 
                      name="MA50" 
                    />
                  </>
                )}
                <Legend />
              </ComposedChart>
            )}
          </ResponsiveContainer>
        </div>
        
        {showListings && (
          <div className="mt-3">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h6 className="text-white mb-0">Top Cryptocurrencies</h6>
              <small className="text-muted">Click to select</small>
            </div>
            
            {listingsLoading ? (
              <div className="text-center py-3">
                <Spinner animation="border" size="sm" variant="primary" />
                <span className="ms-2 text-muted">Loading listings...</span>
              </div>
            ) : (
              <Table hover responsive size="sm" className="crypto-listings">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th className="text-end">Price</th>
                    <th className="text-end">24h %</th>
                  </tr>
                </thead>
                <tbody>
                  {cryptoListings.slice(0, 5).map((crypto, index) => (
                    <tr 
                      key={crypto.id} 
                      className="cursor-pointer"
                      onClick={() => handleCryptoSelect(crypto)}
                    >
                      <td>{index + 1}</td>
                      <td>
                        <div className="d-flex align-items-center">
                          <div className="crypto-icon me-2 rounded-circle d-flex align-items-center justify-content-center" 
                            style={{ 
                              width: '24px', 
                              height: '24px', 
                              fontSize: '12px', 
                              background: 'rgba(247, 147, 26, 0.15)', 
                              color: '#f7931a' 
                            }}>
                            {crypto.symbol.substring(0, 1)}
                          </div>
                          <div>
                            <div className="text-white">{crypto.name}</div>
                            <small className="text-muted">{crypto.symbol}</small>
                          </div>
                        </div>
                      </td>
                      <td className={`text-end ${priceChangeMap[crypto.id] === 'up' ? 'text-success animate-pulse' : priceChangeMap[crypto.id] === 'down' ? 'text-danger animate-pulse' : ''}`}>
                        {formatPrice(crypto.price)}
                      </td>
                      <td className={`text-end ${crypto.change24h >= 0 ? 'text-success' : 'text-danger'}`}>
                        {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h.toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            )}
            
            <div className="text-center mt-2">
              <Button 
                variant="link" 
                size="sm" 
                className="text-muted"
                onClick={() => setShowListings(false)}
              >
                Hide Listings
              </Button>
            </div>
          </div>
        )}
        
        {!showListings && assetType === 'crypto' && (
          <div className="text-center mt-3">
            <Button 
              variant="outline-secondary" 
              size="sm"
              onClick={() => setShowListings(true)}
            >
              Show Top Cryptocurrencies
            </Button>
          </div>
        )}
      </div>
      
      {/* Asset Selection Modal */}
      <Modal show={showAssetModal} onHide={() => setShowAssetModal(false)} centered>
        <Modal.Header closeButton style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <Modal.Title className="text-white">Select Asset</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ background: '#1e293b' }}>
          <Form.Group className="mb-3">
            <Form.Label className="text-white">Asset Type</Form.Label>
            <div>
              <Form.Check
                inline
                type="radio"
                label="Stock"
                name="assetType"
                id="stock-type"
                checked={assetType === 'stock'}
                onChange={() => setAssetType('stock')}
                className="text-white"
              />
              <Form.Check
                inline
                type="radio"
                label="Cryptocurrency"
                name="assetType"
                id="crypto-type"
                checked={assetType === 'crypto'}
                onChange={() => setAssetType('crypto')}
                className="text-white"
              />
            </div>
          </Form.Group>
          
          <Form.Group className="mb-3">
            <Form.Label className="text-white">Select {assetType === 'stock' ? 'Stock' : 'Cryptocurrency'}</Form.Label>
            <Form.Select 
              value={selectedAsset} 
              onChange={handleAssetChange}
              style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
            >
              {assetType === 'stock' ? (
                <>
                  <option value="AAPL">AAPL - Apple Inc.</option>
                  <option value="MSFT">MSFT - Microsoft Corporation</option>
                  <option value="GOOGL">GOOGL - Alphabet Inc.</option>
                  <option value="AMZN">AMZN - Amazon.com Inc.</option>
                  <option value="TSLA">TSLA - Tesla, Inc.</option>
                  <option value="META">META - Meta Platforms, Inc.</option>
                  <option value="NVDA">NVDA - NVIDIA Corporation</option>
                  <option value="JPM">JPM - JPMorgan Chase & Co.</option>
                </>
              ) : (
                <>
                  <option value="BTC">BTC - Bitcoin</option>
                  <option value="ETH">ETH - Ethereum</option>
                  <option value="SOL">SOL - Solana</option>
                  <option value="ADA">ADA - Cardano</option>
                  <option value="XRP">XRP - XRP</option>
                  <option value="DOT">DOT - Polkadot</option>
                  <option value="DOGE">DOGE - Dogecoin</option>
                  <option value="AVAX">AVAX - Avalanche</option>
                </>
              )}
            </Form.Select>
          </Form.Group>
        </Modal.Body>
        <Modal.Footer style={{ background: '#1e293b', borderTop: '1px solid #334155' }}>
          <Button variant="secondary" onClick={() => setShowAssetModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={() => setShowAssetModal(false)}>
            Apply
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default ChartWidget; 