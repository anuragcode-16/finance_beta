import { useState, useEffect, ChangeEvent } from 'react';
import { 
  Form, 
  Button, 
  Table, 
  Badge, 
  Dropdown, 
  Modal, 
  Spinner,
  InputGroup,
  Alert as BootstrapAlert
} from 'react-bootstrap';
import { 
  FaPlus, 
  FaTrash, 
  FaBell, 
  FaToggleOn, 
  FaToggleOff, 
  FaEllipsisV,
  FaExclamationTriangle,
  FaSyncAlt
} from 'react-icons/fa';
import { WidgetConfig } from '../../types/market';
import { useDashboard } from '../../context/DashboardContext';
import { alertService, Alert as AlertType } from '../../services/AlertService';

interface AlertWidgetProps {
  widget: WidgetConfig;
}

const AlertWidget = ({ widget }: AlertWidgetProps) => {
  const [alerts, setAlerts] = useState<AlertType[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const { removeWidget } = useDashboard();
  
  // New alert form state
  const [newAlert, setNewAlert] = useState({
    symbol: 'AAPL',
    type: 'price' as 'price' | 'volume' | 'indicator',
    condition: 'above' as 'above' | 'below' | 'crosses',
    value: 0,
    notifyVia: ['push'],
  });

  // Load alerts on component mount
  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = () => {
    setLoading(true);
    try {
      const currentAlerts = alertService.getAlerts();
      setAlerts(currentAlerts);
    } catch (error) {
      console.error('Error loading alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddAlert = () => {
    try {
      const alert = alertService.addAlert({
        ...newAlert,
        active: true,
        notifyVia: newAlert.notifyVia as ('push' | 'email')[],
      });
      
      setAlerts(prev => [...prev, alert]);
      setShowAddModal(false);
      
      // Reset form
      setNewAlert({
        symbol: 'AAPL',
        type: 'price' as 'price' | 'volume' | 'indicator',
        condition: 'above' as 'above' | 'below' | 'crosses',
        value: 0,
        notifyVia: ['push'],
      });
    } catch (error) {
      console.error('Error adding alert:', error);
    }
  };

  const handleRemoveAlert = (id: string) => {
    try {
      alertService.removeAlert(id);
      setAlerts(prev => prev.filter(alert => alert.id !== id));
    } catch (error) {
      console.error('Error removing alert:', error);
    }
  };

  const handleToggleAlert = (id: string, active: boolean) => {
    try {
      alertService.toggleAlert(id, active);
      setAlerts(prev => 
        prev.map(alert => 
          alert.id === id ? { ...alert, active } : alert
        )
      );
    } catch (error) {
      console.error('Error toggling alert:', error);
    }
  };

  const handleInputChange = (e: ChangeEvent<HTMLElement>) => {
    const target = e.target as HTMLInputElement | HTMLSelectElement;
    const { name, value } = target;
    
    if (name === 'value') {
      setNewAlert(prev => ({ ...prev, [name]: parseFloat(value) }));
    } else if (name === 'type') {
      setNewAlert(prev => ({ 
        ...prev, 
        [name]: value as 'price' | 'volume' | 'indicator' 
      }));
    } else if (name === 'condition') {
      setNewAlert(prev => ({ 
        ...prev, 
        [name]: value as 'above' | 'below' | 'crosses' 
      }));
    } else {
      setNewAlert(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleNotifyViaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { checked, value } = e.target;
    
    setNewAlert(prev => {
      const notifyVia = [...prev.notifyVia];
      
      if (checked && !notifyVia.includes(value)) {
        notifyVia.push(value);
      } else if (!checked && notifyVia.includes(value)) {
        const index = notifyVia.indexOf(value);
        notifyVia.splice(index, 1);
      }
      
      return { ...prev, notifyVia };
    });
  };

  if (loading && alerts.length === 0) {
    return (
      <div className="widget shadow-md" style={{ 
        gridColumn: `span ${widget.position.width}`, 
        gridRow: `span ${widget.position.height}`,
        background: '#1e293b'
      }}>
        <div className="widget-header" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <h3 className="widget-title text-white">Price Alerts</h3>
        </div>
        <div className="widget-body d-flex justify-content-center align-items-center">
          <div className="text-center">
            <Spinner animation="border" role="status" variant="primary" className="mb-3">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
            <p className="text-muted mb-0">Loading alerts...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="widget shadow-md" style={{ 
      gridColumn: `span ${widget.position.width}`, 
      gridRow: `span ${widget.position.height}`,
      background: '#1e293b'
    }}>
      <div className="widget-header d-flex justify-content-between align-items-center" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
        <div className="d-flex align-items-center">
          <h3 className="widget-title text-white">Price Alerts</h3>
          <Badge 
            bg="info" 
            className="ms-2" 
            pill
            style={{ background: '#0ea5e9' }}
          >
            {alerts.length}
          </Badge>
        </div>
        <div className="d-flex align-items-center">
          <Button 
            variant="outline-light" 
            size="sm" 
            className="me-2"
            onClick={() => setShowAddModal(true)}
          >
            <FaPlus className="me-1" /> New Alert
          </Button>
          <Dropdown align="end">
            <Dropdown.Toggle as="div" className="cursor-pointer text-white">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item onClick={loadAlerts}>
                <FaSyncAlt className="me-2" /> Refresh Alerts
              </Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item onClick={() => removeWidget(widget.id)}>
                Remove Widget
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      <div className="widget-body p-0">
        {alerts.length === 0 ? (
          <div className="text-center p-4">
            <div className="mb-3">
              <FaBell size={48} className="text-muted" />
            </div>
            <h5 className="text-white">No alerts set</h5>
            <p className="text-muted">Create alerts to get notified when market conditions change</p>
            <Button 
              variant="primary" 
              onClick={() => setShowAddModal(true)}
            >
              <FaPlus className="me-2" /> Create Alert
            </Button>
          </div>
        ) : (
          <Table hover variant="dark" className="mb-0" style={{ background: 'transparent' }}>
            <thead style={{ background: '#1a2234' }}>
              <tr>
                <th style={{ borderColor: '#334155', width: '15%' }}>Symbol</th>
                <th style={{ borderColor: '#334155', width: '15%' }}>Type</th>
                <th style={{ borderColor: '#334155', width: '40%' }}>Condition</th>
                <th style={{ borderColor: '#334155', width: '15%' }}>Notify Via</th>
                <th style={{ borderColor: '#334155', width: '15%' }} className="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              {alerts.map(alert => (
                <tr key={alert.id}>
                  <td style={{ borderColor: '#334155' }} className="align-middle">
                    <Badge bg="secondary" className="fw-normal">
                      {alert.symbol}
                    </Badge>
                  </td>
                  <td style={{ borderColor: '#334155' }} className="align-middle text-capitalize">
                    {alert.type}
                  </td>
                  <td style={{ borderColor: '#334155' }} className="align-middle">
                    <span className="text-white">
                      {alert.type} {alert.condition} {alert.value}
                    </span>
                  </td>
                  <td style={{ borderColor: '#334155' }} className="align-middle">
                    {alert.notifyVia.includes('push') && (
                      <Badge bg="info" className="me-1">Push</Badge>
                    )}
                    {alert.notifyVia.includes('email') && (
                      <Badge bg="primary">Email</Badge>
                    )}
                  </td>
                  <td style={{ borderColor: '#334155' }} className="text-end">
                    <Button 
                      variant="link" 
                      className="p-0 me-3 text-white"
                      onClick={() => handleToggleAlert(alert.id, !alert.active)}
                    >
                      {alert.active ? <FaToggleOn size={20} className="text-success" /> : <FaToggleOff size={20} className="text-muted" />}
                    </Button>
                    <Button 
                      variant="link" 
                      className="p-0 text-danger"
                      onClick={() => handleRemoveAlert(alert.id)}
                    >
                      <FaTrash size={16} />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </div>

      {/* Add Alert Modal */}
      <Modal show={showAddModal} onHide={() => setShowAddModal(false)} centered>
        <Modal.Header closeButton style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <Modal.Title className="text-white">Create New Alert</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ background: '#1e293b' }}>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label className="text-white">Asset Symbol</Form.Label>
              <Form.Select 
                name="symbol" 
                value={newAlert.symbol} 
                onChange={handleInputChange}
                style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
              >
                <option value="AAPL">AAPL - Apple Inc.</option>
                <option value="MSFT">MSFT - Microsoft Corporation</option>
                <option value="GOOGL">GOOGL - Alphabet Inc.</option>
                <option value="AMZN">AMZN - Amazon.com Inc.</option>
                <option value="TSLA">TSLA - Tesla, Inc.</option>
                <option value="BTC">BTC - Bitcoin</option>
                <option value="ETH">ETH - Ethereum</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Alert Type</Form.Label>
              <Form.Select 
                name="type" 
                value={newAlert.type} 
                onChange={handleInputChange}
                style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
              >
                <option value="price">Price</option>
                <option value="volume">Volume</option>
                <option value="indicator">Indicator</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Condition</Form.Label>
              <Form.Select 
                name="condition" 
                value={newAlert.condition} 
                onChange={handleInputChange}
                style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
              >
                <option value="above">Above</option>
                <option value="below">Below</option>
                <option value="crosses">Crosses</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Value</Form.Label>
              <InputGroup>
                {newAlert.type === 'price' && <InputGroup.Text style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}>$</InputGroup.Text>}
                <Form.Control 
                  type="number" 
                  name="value" 
                  value={newAlert.value} 
                  onChange={handleInputChange}
                  style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
                />
              </InputGroup>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Notify Via</Form.Label>
              <div>
                <Form.Check 
                  type="checkbox" 
                  id="notify-push" 
                  label="Push Notification" 
                  value="push"
                  checked={newAlert.notifyVia.includes('push')}
                  onChange={handleNotifyViaChange}
                  className="text-white"
                />
                <Form.Check 
                  type="checkbox" 
                  id="notify-email" 
                  label="Email" 
                  value="email"
                  checked={newAlert.notifyVia.includes('email')}
                  onChange={handleNotifyViaChange}
                  className="text-white"
                />
              </div>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer style={{ background: '#1e293b', borderTop: '1px solid #334155' }}>
          <Button variant="secondary" onClick={() => setShowAddModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleAddAlert}>
            Create Alert
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default AlertWidget; 