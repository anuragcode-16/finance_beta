import { useState, ChangeEvent } from 'react';
import { 
  Table, 
  Badge, 
  Dropdown, 
  Button, 
  Modal, 
  Form, 
  InputGroup,
  ProgressBar,
  Tabs,
  Tab
} from 'react-bootstrap';
import { 
  FaEllipsisV, 
  FaPlus, 
  FaTrash, 
  FaEdit, 
  FaChartPie,
  FaArrowUp,
  FaArrowDown,
  FaExchangeAlt,
  FaSyncAlt
} from 'react-icons/fa';
import { WidgetConfig } from '../../types/market';
import { useDashboard } from '../../context/DashboardContext';

interface PortfolioWidgetProps {
  widget: WidgetConfig;
}

interface PortfolioHolding {
  id: string;
  symbol: string;
  name: string;
  type: 'stock' | 'crypto';
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  value: number;
  profitLoss: number;
  profitLossPercent: number;
  allocation: number;
}

const PortfolioWidget = ({ widget }: PortfolioWidgetProps) => {
  const [holdings, setHoldings] = useState<PortfolioHolding[]>([
    {
      id: '1',
      symbol: 'AAPL',
      name: 'Apple Inc.',
      type: 'stock',
      quantity: 10,
      averagePrice: 175.50,
      currentPrice: 182.52,
      value: 1825.20,
      profitLoss: 70.20,
      profitLossPercent: 4.00,
      allocation: 35.2
    },
    {
      id: '2',
      symbol: 'MSFT',
      name: 'Microsoft Corporation',
      type: 'stock',
      quantity: 5,
      averagePrice: 410.25,
      currentPrice: 417.88,
      value: 2089.40,
      profitLoss: 38.15,
      profitLossPercent: 1.86,
      allocation: 40.3
    },
    {
      id: '3',
      symbol: 'BTC',
      name: 'Bitcoin',
      type: 'crypto',
      quantity: 0.25,
      averagePrice: 60000,
      currentPrice: 62500,
      value: 15625,
      profitLoss: 625,
      profitLossPercent: 4.17,
      allocation: 24.5
    }
  ]);
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('holdings');
  const [editingHolding, setEditingHolding] = useState<PortfolioHolding | null>(null);
  
  const { removeWidget } = useDashboard();
  
  const [newHolding, setNewHolding] = useState({
    symbol: '',
    name: '',
    type: 'stock',
    quantity: 0,
    averagePrice: 0
  });

  const totalValue = holdings.reduce((sum, holding) => sum + holding.value, 0);
  const totalProfitLoss = holdings.reduce((sum, holding) => sum + holding.profitLoss, 0);
  const totalProfitLossPercent = totalValue > 0 
    ? (totalProfitLoss / (totalValue - totalProfitLoss)) * 100 
    : 0;

  const handleAddHolding = () => {
    const currentPrice = newHolding.averagePrice; // In a real app, this would come from an API
    const value = newHolding.quantity * currentPrice;
    
    const newItem: PortfolioHolding = {
      id: Date.now().toString(),
      ...newHolding,
      type: newHolding.type as 'stock' | 'crypto',
      currentPrice,
      value,
      profitLoss: 0,
      profitLossPercent: 0,
      allocation: 0
    };
    
    // Add the new holding
    const updatedHoldings = [...holdings, newItem];
    
    // Recalculate allocations
    const newTotalValue = updatedHoldings.reduce((sum, holding) => sum + holding.value, 0);
    const holdingsWithAllocations = updatedHoldings.map(holding => ({
      ...holding,
      allocation: (holding.value / newTotalValue) * 100
    }));
    
    setHoldings(holdingsWithAllocations);
    setShowAddModal(false);
    
    // Reset form
    setNewHolding({
      symbol: '',
      name: '',
      type: 'stock',
      quantity: 0,
      averagePrice: 0
    });
  };

  const handleEditHolding = () => {
    if (!editingHolding) return;
    
    const value = editingHolding.quantity * editingHolding.currentPrice;
    const profitLoss = value - (editingHolding.quantity * editingHolding.averagePrice);
    const profitLossPercent = editingHolding.averagePrice > 0 
      ? (profitLoss / (editingHolding.quantity * editingHolding.averagePrice)) * 100 
      : 0;
    
    const updatedHolding = {
      ...editingHolding,
      value,
      profitLoss,
      profitLossPercent
    };
    
    // Update the holding
    const updatedHoldings = holdings.map(holding => 
      holding.id === updatedHolding.id ? updatedHolding : holding
    );
    
    // Recalculate allocations
    const newTotalValue = updatedHoldings.reduce((sum, holding) => sum + holding.value, 0);
    const holdingsWithAllocations = updatedHoldings.map(holding => ({
      ...holding,
      allocation: (holding.value / newTotalValue) * 100
    }));
    
    setHoldings(holdingsWithAllocations);
    setShowEditModal(false);
    setEditingHolding(null);
  };

  const handleRemoveHolding = (id: string) => {
    // Remove the holding
    const updatedHoldings = holdings.filter(holding => holding.id !== id);
    
    // Recalculate allocations
    const newTotalValue = updatedHoldings.reduce((sum, holding) => sum + holding.value, 0);
    const holdingsWithAllocations = updatedHoldings.map(holding => ({
      ...holding,
      allocation: newTotalValue > 0 ? (holding.value / newTotalValue) * 100 : 0
    }));
    
    setHoldings(holdingsWithAllocations);
  };

  const handleInputChange = (e: ChangeEvent<HTMLElement>) => {
    const target = e.target as HTMLInputElement | HTMLSelectElement;
    const { name, value } = target;
    
    if (name === 'quantity' || name === 'averagePrice') {
      setNewHolding(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    } else {
      setNewHolding(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleEditInputChange = (e: ChangeEvent<HTMLElement>) => {
    if (!editingHolding) return;
    
    const target = e.target as HTMLInputElement | HTMLSelectElement;
    const { name, value } = target;
    
    if (name === 'quantity' || name === 'averagePrice' || name === 'currentPrice') {
      setEditingHolding(prev => ({ ...prev!, [name]: parseFloat(value) || 0 }));
    } else {
      setEditingHolding(prev => ({ ...prev!, [name]: value }));
    }
  };

  const startEditHolding = (holding: PortfolioHolding) => {
    setEditingHolding(holding);
    setShowEditModal(true);
  };

  return (
    <div className="widget shadow-md" style={{ 
      gridColumn: `span ${widget.position.width}`, 
      gridRow: `span ${widget.position.height}`,
      background: '#1e293b'
    }}>
      <div className="widget-header d-flex justify-content-between align-items-center" style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
        <div className="d-flex align-items-center">
          <h3 className="widget-title text-white">Portfolio</h3>
          <Badge 
            bg="success" 
            className="ms-2" 
            pill
            style={{ background: totalProfitLossPercent >= 0 ? '#22c55e' : '#ef4444' }}
          >
            {totalProfitLossPercent >= 0 ? '+' : ''}{totalProfitLossPercent.toFixed(2)}%
          </Badge>
        </div>
        <div className="d-flex align-items-center">
          <Button 
            variant="outline-light" 
            size="sm" 
            className="me-2"
            onClick={() => setShowAddModal(true)}
          >
            <FaPlus className="me-1" /> Add Asset
          </Button>
          <Dropdown align="end">
            <Dropdown.Toggle as="div" className="cursor-pointer text-white">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item>
                <FaSyncAlt className="me-2" /> Refresh Data
              </Dropdown.Item>
              <Dropdown.Item>
                <FaExchangeAlt className="me-2" /> Import Transactions
              </Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item onClick={() => removeWidget(widget.id)}>
                Remove Widget
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      <div className="widget-body p-0">
        <div className="p-3" style={{ borderBottom: '1px solid #334155' }}>
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h5 className="text-white mb-1">Total Value</h5>
              <h3 className="text-white mb-0">${totalValue.toFixed(2)}</h3>
            </div>
            <div className="text-end">
              <h5 className="text-white mb-1">Total Profit/Loss</h5>
              <h3 className={totalProfitLoss >= 0 ? 'text-success mb-0' : 'text-danger mb-0'}>
                {totalProfitLoss >= 0 ? '+' : ''}${totalProfitLoss.toFixed(2)}
              </h3>
            </div>
          </div>
        </div>
        
        <Tabs
          activeKey={activeTab}
          onSelect={(k) => setActiveTab(k || 'holdings')}
          className="mb-0 portfolio-tabs"
          style={{ borderBottom: '1px solid #334155' }}
        >
          <Tab eventKey="holdings" title="Holdings">
            <div className="p-0">
              {holdings.length === 0 ? (
                <div className="text-center p-4">
                  <div className="mb-3">
                    <FaChartPie size={48} className="text-muted" />
                  </div>
                  <h5 className="text-white">No assets in portfolio</h5>
                  <p className="text-muted">Add assets to start tracking your portfolio</p>
                  <Button 
                    variant="primary" 
                    onClick={() => setShowAddModal(true)}
                  >
                    <FaPlus className="me-2" /> Add Asset
                  </Button>
                </div>
              ) : (
                <Table hover variant="dark" className="mb-0" style={{ background: 'transparent' }}>
                  <thead style={{ background: '#1a2234' }}>
                    <tr>
                      <th style={{ borderColor: '#334155', width: '20%' }}>Asset</th>
                      <th style={{ borderColor: '#334155', width: '15%' }} className="text-end">Quantity</th>
                      <th style={{ borderColor: '#334155', width: '15%' }} className="text-end">Avg. Price</th>
                      <th style={{ borderColor: '#334155', width: '15%' }} className="text-end">Current</th>
                      <th style={{ borderColor: '#334155', width: '20%' }} className="text-end">Value</th>
                      <th style={{ borderColor: '#334155', width: '15%' }} className="text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {holdings.map(holding => (
                      <tr key={holding.id}>
                        <td style={{ borderColor: '#334155' }} className="align-middle">
                          <div>
                            <Badge 
                              bg={holding.type === 'stock' ? 'info' : 'warning'} 
                              className="me-2"
                              style={{ 
                                background: holding.type === 'stock' ? '#0ea5e9' : '#facc15',
                                color: holding.type === 'stock' ? 'white' : 'black'
                              }}
                            >
                              {holding.symbol}
                            </Badge>
                            <span className="text-white d-none d-md-inline">{holding.name}</span>
                          </div>
                        </td>
                        <td style={{ borderColor: '#334155' }} className="text-end align-middle text-white">
                          {holding.quantity.toFixed(holding.type === 'crypto' ? 6 : 2)}
                        </td>
                        <td style={{ borderColor: '#334155' }} className="text-end align-middle text-white">
                          ${holding.averagePrice.toFixed(2)}
                        </td>
                        <td style={{ borderColor: '#334155' }} className="text-end align-middle text-white">
                          ${holding.currentPrice.toFixed(2)}
                        </td>
                        <td style={{ borderColor: '#334155' }} className="text-end align-middle">
                          <div className="text-white">${holding.value.toFixed(2)}</div>
                          <div className={holding.profitLoss >= 0 ? 'text-success small' : 'text-danger small'}>
                            {holding.profitLoss >= 0 ? <FaArrowUp className="me-1" /> : <FaArrowDown className="me-1" />}
                            {holding.profitLoss >= 0 ? '+' : ''}{holding.profitLossPercent.toFixed(2)}%
                          </div>
                        </td>
                        <td style={{ borderColor: '#334155' }} className="text-end align-middle">
                          <Button 
                            variant="link" 
                            className="p-0 me-2 text-white"
                            onClick={() => startEditHolding(holding)}
                          >
                            <FaEdit size={16} />
                          </Button>
                          <Button 
                            variant="link" 
                            className="p-0 text-danger"
                            onClick={() => handleRemoveHolding(holding.id)}
                          >
                            <FaTrash size={16} />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}
            </div>
          </Tab>
          <Tab eventKey="allocation" title="Allocation">
            <div className="p-3">
              {holdings.length === 0 ? (
                <div className="text-center p-4">
                  <div className="mb-3">
                    <FaChartPie size={48} className="text-muted" />
                  </div>
                  <h5 className="text-white">No assets in portfolio</h5>
                  <p className="text-muted">Add assets to see your allocation</p>
                </div>
              ) : (
                <div>
                  {holdings.map(holding => (
                    <div key={holding.id} className="mb-3">
                      <div className="d-flex justify-content-between mb-1">
                        <div>
                          <Badge 
                            bg={holding.type === 'stock' ? 'info' : 'warning'} 
                            className="me-2"
                            style={{ 
                              background: holding.type === 'stock' ? '#0ea5e9' : '#facc15',
                              color: holding.type === 'stock' ? 'white' : 'black'
                            }}
                          >
                            {holding.symbol}
                          </Badge>
                          <span className="text-white">{holding.name}</span>
                        </div>
                        <div className="text-white">{holding.allocation.toFixed(1)}%</div>
                      </div>
                      <ProgressBar 
                        now={holding.allocation} 
                        variant={holding.type === 'stock' ? 'info' : 'warning'} 
                        style={{ height: '8px' }}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Tab>
        </Tabs>
      </div>

      {/* Add Asset Modal */}
      <Modal show={showAddModal} onHide={() => setShowAddModal(false)} centered>
        <Modal.Header closeButton style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <Modal.Title className="text-white">Add Asset</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ background: '#1e293b' }}>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label className="text-white">Asset Type</Form.Label>
              <Form.Select 
                name="type" 
                value={newHolding.type} 
                onChange={handleInputChange}
                style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
              >
                <option value="stock">Stock</option>
                <option value="crypto">Cryptocurrency</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Symbol</Form.Label>
              <Form.Control 
                type="text" 
                name="symbol" 
                value={newHolding.symbol} 
                onChange={handleInputChange}
                placeholder="e.g. AAPL, BTC"
                style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Name</Form.Label>
              <Form.Control 
                type="text" 
                name="name" 
                value={newHolding.name} 
                onChange={handleInputChange}
                placeholder="e.g. Apple Inc., Bitcoin"
                style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Quantity</Form.Label>
              <Form.Control 
                type="number" 
                name="quantity" 
                value={newHolding.quantity} 
                onChange={handleInputChange}
                min="0"
                step={newHolding.type === 'crypto' ? '0.000001' : '0.01'}
                style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label className="text-white">Average Purchase Price</Form.Label>
              <InputGroup>
                <InputGroup.Text style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}>$</InputGroup.Text>
                <Form.Control 
                  type="number" 
                  name="averagePrice" 
                  value={newHolding.averagePrice} 
                  onChange={handleInputChange}
                  min="0"
                  step="0.01"
                  style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
                />
              </InputGroup>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer style={{ background: '#1e293b', borderTop: '1px solid #334155' }}>
          <Button variant="secondary" onClick={() => setShowAddModal(false)}>
            Cancel
          </Button>
          <Button 
            variant="primary" 
            onClick={handleAddHolding}
            disabled={!newHolding.symbol || !newHolding.name || newHolding.quantity <= 0}
          >
            Add Asset
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Asset Modal */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} centered>
        <Modal.Header closeButton style={{ background: '#1a2234', borderBottom: '1px solid #334155' }}>
          <Modal.Title className="text-white">Edit Asset</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ background: '#1e293b' }}>
          {editingHolding && (
            <Form>
              <Form.Group className="mb-3">
                <Form.Label className="text-white">Symbol</Form.Label>
                <Form.Control 
                  type="text" 
                  name="symbol" 
                  value={editingHolding.symbol} 
                  onChange={handleEditInputChange}
                  style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
                  readOnly
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="text-white">Name</Form.Label>
                <Form.Control 
                  type="text" 
                  name="name" 
                  value={editingHolding.name} 
                  onChange={handleEditInputChange}
                  style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="text-white">Quantity</Form.Label>
                <Form.Control 
                  type="number" 
                  name="quantity" 
                  value={editingHolding.quantity} 
                  onChange={handleEditInputChange}
                  min="0"
                  step={editingHolding.type === 'crypto' ? '0.000001' : '0.01'}
                  style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="text-white">Average Purchase Price</Form.Label>
                <InputGroup>
                  <InputGroup.Text style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}>$</InputGroup.Text>
                  <Form.Control 
                    type="number" 
                    name="averagePrice" 
                    value={editingHolding.averagePrice} 
                    onChange={handleEditInputChange}
                    min="0"
                    step="0.01"
                    style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
                  />
                </InputGroup>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="text-white">Current Price</Form.Label>
                <InputGroup>
                  <InputGroup.Text style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}>$</InputGroup.Text>
                  <Form.Control 
                    type="number" 
                    name="currentPrice" 
                    value={editingHolding.currentPrice} 
                    onChange={handleEditInputChange}
                    min="0"
                    step="0.01"
                    style={{ background: '#293548', color: 'white', border: '1px solid #334155' }}
                  />
                </InputGroup>
                <Form.Text className="text-muted">
                  In a real app, this would be updated automatically from market data.
                </Form.Text>
              </Form.Group>
            </Form>
          )}
        </Modal.Body>
        <Modal.Footer style={{ background: '#1e293b', borderTop: '1px solid #334155' }}>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>
          <Button 
            variant="primary" 
            onClick={handleEditHolding}
            disabled={!editingHolding || editingHolding.quantity <= 0}
          >
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default PortfolioWidget; 