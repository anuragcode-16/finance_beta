import { useState, useEffect } from 'react';
import { Table, Spinner, Dropdown } from 'react-bootstrap';
import { marketWS, MarketUpdate } from '../../services/WebSocketService';
import { useDashboard } from '../../context/DashboardContext';
import { FaEllipsisV } from 'react-icons/fa';
import { WidgetConfig } from '../../types/market';

interface OrderBookWidgetProps {
  widget: WidgetConfig;
}

interface OrderBookLevel {
  price: number;
  size: number;
  total: number;
  percentage: number;
}

const OrderBookWidget = ({ widget }: OrderBookWidgetProps) => {
  const [orderBook, setOrderBook] = useState<{ bids: OrderBookLevel[], asks: OrderBookLevel[] }>({
    bids: [],
    asks: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { removeWidget } = useDashboard();

  useEffect(() => {
    const symbol = widget.asset || 'BTCUSD';
    
    const handleUpdate = (update: MarketUpdate) => {
      if (update.symbol === symbol && update.orderBook) {
        const processOrders = (orders: [number, number][]): OrderBookLevel[] => {
          let total = 0;
          const levels = orders.map(([price, size]) => {
            total += size;
            return { price, size, total, percentage: 0 };
          });

          const maxTotal = total;
          return levels.map(level => ({
            ...level,
            percentage: (level.total / maxTotal) * 100
          }));
        };

        setOrderBook({
          bids: processOrders(update.orderBook.bids),
          asks: processOrders(update.orderBook.asks.reverse())
        });
        setLoading(false);
      }
    };

    marketWS.subscribe(symbol);
    marketWS.on('market-update', handleUpdate);

    return () => {
      marketWS.unsubscribe(symbol);
      marketWS.off('market-update', handleUpdate);
    };
  }, [widget.asset]);

  const formatNumber = (num: number, decimals = 2) => {
    return num.toLocaleString(undefined, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  };

  if (loading) {
    return (
      <div className="widget" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
        <div className="widget-header">
          <h3 className="widget-title">{widget.title}</h3>
        </div>
        <div className="widget-body d-flex justify-content-center align-items-center">
          <Spinner animation="border" role="status" variant="primary">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="widget" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
        <div className="widget-header">
          <h3 className="widget-title">{widget.title}</h3>
        </div>
        <div className="widget-body text-center">
          <div className="text-danger">{error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="widget" style={{ gridColumn: `span ${widget.position.width}`, gridRow: `span ${widget.position.height}` }}>
      <div className="widget-header">
        <h3 className="widget-title">{widget.title}</h3>
        <div className="d-flex align-items-center">
          <div className="text-muted small me-3">Last updated: {new Date().toLocaleTimeString()}</div>
          <Dropdown align="end">
            <Dropdown.Toggle as="div" className="cursor-pointer">
              <FaEllipsisV />
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item onClick={() => removeWidget(widget.id)}>Remove Widget</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      <div className="widget-body">
        <div className="order-book-container">
          <div className="order-book-asks">
            <Table hover size="sm" className="mb-0">
              <thead>
                <tr>
                  <th>Price</th>
                  <th className="text-end">Size</th>
                  <th className="text-end">Total</th>
                </tr>
              </thead>
              <tbody>
                {orderBook.asks.map((level, index) => (
                  <tr key={`ask-${index}`}>
                    <td className="text-danger">${formatNumber(level.price)}</td>
                    <td className="text-end">{formatNumber(level.size)}</td>
                    <td className="text-end">{formatNumber(level.total)}</td>
                    <td className="order-book-depth" style={{ width: '100px' }}>
                      <div
                        className="depth-bar depth-bar-ask"
                        style={{ width: `${level.percentage}%` }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
          
          <div className="spread-indicator text-center py-2">
            <span className="text-muted">Spread: </span>
            <span className="fw-bold">
              ${formatNumber(orderBook.asks[0]?.price - orderBook.bids[0]?.price)}
            </span>
          </div>

          <div className="order-book-bids">
            <Table hover size="sm" className="mb-0">
              <tbody>
                {orderBook.bids.map((level, index) => (
                  <tr key={`bid-${index}`}>
                    <td className="text-success">${formatNumber(level.price)}</td>
                    <td className="text-end">{formatNumber(level.size)}</td>
                    <td className="text-end">{formatNumber(level.total)}</td>
                    <td className="order-book-depth" style={{ width: '100px' }}>
                      <div
                        className="depth-bar depth-bar-bid"
                        style={{ width: `${level.percentage}%` }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderBookWidget; 