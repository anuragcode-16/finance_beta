import { useState, useEffect } from 'react';
import { Offcanvas, Badge, Button, ListGroup } from 'react-bootstrap';
import { 
  FaRegBell, 
  FaCheck, 
  FaTrash, 
  FaRegCheckCircle,
  FaExclamationTriangle
} from 'react-icons/fa';
import { alertService, AlertNotification } from '../services/AlertService';

interface NotificationCenterProps {
  show: boolean;
  onHide: () => void;
}

const NotificationCenter = ({ show, onHide }: NotificationCenterProps) => {
  const [notifications, setNotifications] = useState<AlertNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);

  useEffect(() => {
    // Load initial notifications
    loadNotifications();

    // Subscribe to new notifications
    const unsubscribe = alertService.subscribe(handleNewNotification);
    
    return () => {
      unsubscribe();
    };
  }, []);

  const loadNotifications = () => {
    const allNotifications = alertService.getNotifications();
    setNotifications(allNotifications);
    updateUnreadCount(allNotifications);
  };

  const handleNewNotification = (notification: AlertNotification) => {
    setNotifications(prev => [notification, ...prev]);
    setUnreadCount(prev => prev + 1);
  };

  const updateUnreadCount = (notifs: AlertNotification[]) => {
    const unread = notifs.filter(n => !n.read).length;
    setUnreadCount(unread);
  };

  const markAsRead = (id: string) => {
    alertService.markNotificationAsRead(id);
    setNotifications(prev => 
      prev.map(n => 
        n.id === id ? { ...n, read: true } : n
      )
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const markAllAsRead = () => {
    const updatedNotifications = notifications.map(n => ({ ...n, read: true }));
    setNotifications(updatedNotifications);
    setUnreadCount(0);
    
    // Update in service
    updatedNotifications.forEach(n => {
      if (!n.read) alertService.markNotificationAsRead(n.id);
    });
  };

  const clearAllNotifications = () => {
    alertService.clearNotifications();
    setNotifications([]);
    setUnreadCount(0);
  };

  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    
    // Less than a minute
    if (diff < 60000) {
      return 'Just now';
    }
    
    // Less than an hour
    if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    }
    
    // Less than a day
    if (diff < 86400000) {
      const hours = Math.floor(diff / 3600000);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    }
    
    // Format as date
    return new Date(date).toLocaleDateString();
  };

  return (
    <Offcanvas 
      show={show} 
      onHide={onHide} 
      placement="end"
      style={{ background: '#1e293b', color: 'white', width: '350px' }}
    >
      <Offcanvas.Header 
        closeButton 
        style={{ borderBottom: '1px solid #334155' }}
      >
        <Offcanvas.Title className="d-flex align-items-center">
          <FaRegBell className="me-2" /> Notifications
          {unreadCount > 0 && (
            <Badge 
              bg="danger" 
              className="ms-2 pulse-animation"
              pill
            >
              {unreadCount}
            </Badge>
          )}
        </Offcanvas.Title>
      </Offcanvas.Header>
      <div className="d-flex justify-content-between p-2" style={{ borderBottom: '1px solid #334155' }}>
        <Button 
          variant="link" 
          size="sm" 
          className="text-white"
          onClick={markAllAsRead}
          disabled={unreadCount === 0}
        >
          <FaCheck className="me-1" /> Mark all as read
        </Button>
        <Button 
          variant="link" 
          size="sm" 
          className="text-white"
          onClick={clearAllNotifications}
          disabled={notifications.length === 0}
        >
          <FaTrash className="me-1" /> Clear all
        </Button>
      </div>
      <Offcanvas.Body className="p-0">
        {notifications.length === 0 ? (
          <div className="text-center p-4">
            <div className="mb-3">
              <FaRegCheckCircle size={48} className="text-muted" />
            </div>
            <h5>No notifications</h5>
            <p className="text-muted">You're all caught up!</p>
          </div>
        ) : (
          <ListGroup variant="flush">
            {notifications.map(notification => (
              <ListGroup.Item 
                key={notification.id}
                style={{ 
                  background: notification.read ? '#1e293b' : '#293548',
                  borderBottom: '1px solid #334155',
                  transition: 'background-color 0.3s'
                }}
                className="notification-item"
              >
                <div className="d-flex">
                  <div className="me-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        background: '#334155'
                      }}
                    >
                      <FaExclamationTriangle className="text-warning" />
                    </div>
                  </div>
                  <div className="flex-grow-1">
                    <div className="d-flex justify-content-between align-items-start">
                      <div>
                        <Badge bg="secondary" className="mb-1">
                          {notification.symbol}
                        </Badge>
                        {!notification.read && (
                          <Badge bg="danger" className="ms-2 mb-1" pill>New</Badge>
                        )}
                      </div>
                      <small className="text-muted">
                        {formatTimestamp(notification.timestamp)}
                      </small>
                    </div>
                    <p className="mb-1">{notification.message}</p>
                    {!notification.read && (
                      <Button 
                        variant="link" 
                        size="sm" 
                        className="p-0 text-primary"
                        onClick={() => markAsRead(notification.id)}
                      >
                        Mark as read
                      </Button>
                    )}
                  </div>
                </div>
              </ListGroup.Item>
            ))}
          </ListGroup>
        )}
      </Offcanvas.Body>
    </Offcanvas>
  );
};

export default NotificationCenter; 