import { useState, useEffect } from 'react';
import { Container, Row, Col, Button, Dropdown, Badge, OverlayTrigger, Tooltip } from 'react-bootstrap';
import { useDashboard } from '../../context/DashboardContext';
import { useTheme } from '../../context/ThemeContext';
import { 
  FaSun, FaMoon, FaPlus, FaCog, FaChartLine, 
  FaTable, FaChartBar, FaBitcoin, FaSearch,
  FaRegBell, FaUserCircle, FaTachometerAlt, 
  FaExchangeAlt, FaChartPie, FaBell
} from 'react-icons/fa';
import StockWidget from '../widgets/StockWidget';
import CryptoWidget from '../widgets/CryptoWidget';
import ChartWidget from '../widgets/ChartWidget';
import IndicatorWidget from '../widgets/IndicatorWidget';
import AlertWidget from '../widgets/AlertWidget';
import PortfolioWidget from '../widgets/PortfolioWidget';
import NotificationCenter from '../NotificationCenter';
import AuthManager from '../auth/AuthManager';
import { alertService } from '../../services/AlertService';

const Dashboard = () => {
  const { widgets, addWidget } = useDashboard();
  const { theme, toggleTheme } = useTheme();
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(2); // Initial unread count

  // Subscribe to notifications
  useEffect(() => {
    const unsubscribe = alertService.subscribe(() => {
      setUnreadCount(prev => prev + 1);
    });
    
    return () => {
      unsubscribe();
    };
  }, []);

  const handleAddStockWidget = () => {
    addWidget({
      type: 'price',
      title: 'Stock Overview',
      position: { x: 0, y: 0, width: 6, height: 4 },
    });
  };

  const handleAddCryptoWidget = () => {
    addWidget({
      type: 'price',
      title: 'Crypto Overview',
      position: { x: 6, y: 0, width: 6, height: 4 },
    });
  };

  const handleAddChartWidget = () => {
    addWidget({
      type: 'chart',
      title: 'Price Chart',
      asset: 'AAPL',
      position: { x: 0, y: 4, width: 8, height: 6 },
      settings: { timeframe: '1m' },
    });
  };

  const handleAddIndicatorWidget = () => {
    addWidget({
      type: 'indicator',
      title: 'Technical Indicators',
      asset: 'AAPL',
      position: { x: 8, y: 4, width: 4, height: 6 },
    });
  };

  const handleAddAlertWidget = () => {
    addWidget({
      type: 'alert',
      title: 'Price Alerts',
      position: { x: 0, y: 10, width: 6, height: 6 },
    });
  };

  const handleAddPortfolioWidget = () => {
    addWidget({
      type: 'portfolio',
      title: 'Portfolio',
      position: { x: 6, y: 10, width: 6, height: 6 },
    });
  };

  // Function to calculate grid positions to avoid overlaps
  const calculateGridPositions = () => {
    // Create a copy of widgets to sort by y position
    const sortedWidgets = [...widgets].sort((a, b) => a.position.y - b.position.y);
    
    // Create a grid representation
    const grid = Array(50).fill(null).map(() => Array(12).fill(false));
    
    // Mark occupied cells
    sortedWidgets.forEach(widget => {
      const { x, y, width, height } = widget.position;
      
      // Check if this position would overlap with existing widgets
      let hasOverlap = false;
      for (let i = y; i < y + height; i++) {
        for (let j = x; j < x + width; j++) {
          if (grid[i][j]) {
            hasOverlap = true;
            break;
          }
        }
        if (hasOverlap) break;
      }
      
      // If there's an overlap, find a new position
      if (hasOverlap) {
        // Find the first available position
        let newY = 0;
        let placed = false;
        
        while (!placed && newY < 50) {
          let canPlace = true;
          
          for (let i = newY; i < newY + height; i++) {
            for (let j = x; j < x + width; j++) {
              if (j >= 12 || grid[i][j]) {
                canPlace = false;
                break;
              }
            }
            if (!canPlace) break;
          }
          
          if (canPlace) {
            // Mark the cells as occupied
            for (let i = newY; i < newY + height; i++) {
              for (let j = x; j < x + width; j++) {
                grid[i][j] = true;
              }
            }
            
            // Update the widget position
            widget.position.y = newY;
            placed = true;
          } else {
            newY++;
          }
        }
      } else {
        // Mark the cells as occupied
        for (let i = y; i < y + height; i++) {
          for (let j = x; j < x + width; j++) {
            grid[i][j] = true;
          }
        }
      }
    });
    
    return sortedWidgets;
  };

  const renderWidget = (widget: any) => {
    switch (widget.type) {
      case 'price':
        if (widget.title.includes('Stock')) {
          return <StockWidget key={widget.id} widget={widget} />;
        } else if (widget.title.includes('Crypto')) {
          return <CryptoWidget key={widget.id} widget={widget} />;
        }
        return <div key={widget.id}>Unknown price widget</div>;
      case 'chart':
        return <ChartWidget key={widget.id} widget={widget} />;
      case 'indicator':
        return <IndicatorWidget key={widget.id} widget={widget} />;
      case 'alert':
        return <AlertWidget key={widget.id} widget={widget} />;
      case 'portfolio':
        return <PortfolioWidget key={widget.id} widget={widget} />;
      default:
        return <div key={widget.id}>Unknown widget type</div>;
    }
  };

  const handleNotificationClick = () => {
    setShowNotifications(true);
    setUnreadCount(0);
  };

  // Calculate non-overlapping positions
  const positionedWidgets = calculateGridPositions();

  return (
    <div className={`dashboard ${theme}`}>
      <div className="dashboard-header">
        <div className="dashboard-brand">
          <FaTachometerAlt />
          <h1>MarketPulse</h1>
        </div>
        
        <div className="dashboard-search">
          <div className="search-input">
            <FaSearch />
            <input type="text" placeholder="Search assets, markets, news..." />
          </div>
        </div>
        
        <div className="dashboard-actions">
          <OverlayTrigger
            placement="bottom"
            overlay={<Tooltip id="theme-tooltip">Toggle {theme === 'light' ? 'Dark' : 'Light'} Mode</Tooltip>}
          >
            <Button 
              className="theme-toggle" 
              onClick={toggleTheme}
              aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
            >
              {theme === 'light' ? <FaMoon /> : <FaSun />}
            </Button>
          </OverlayTrigger>
          
          <OverlayTrigger
            placement="bottom"
            overlay={<Tooltip id="notifications-tooltip">Notifications</Tooltip>}
          >
            <Button 
              variant="light" 
              className="position-relative"
              onClick={handleNotificationClick}
            >
              <FaRegBell />
              {unreadCount > 0 && (
                <Badge 
                  bg="danger" 
                  className="position-absolute top-0 start-100 translate-middle badge rounded-pill"
                >
                  {unreadCount}
                </Badge>
              )}
            </Button>
          </OverlayTrigger>
          
          <AuthManager />
        </div>
      </div>
      
      <div className="dashboard-content">
        {widgets.length === 0 ? (
          <div className="empty-state">
            <div className="border-gradient rounded-circle mb-4" style={{ width: '100px', height: '100px', padding: '2px' }}>
              <div className="d-flex align-items-center justify-content-center h-100">
                <FaChartLine size={48} className="text-primary" />
              </div>
            </div>
            <h4>Your dashboard is empty</h4>
            <p>Add widgets to start tracking your investments and get real-time market insights</p>
            <div className="d-flex flex-wrap justify-content-center gap-2">
              <Button variant="primary" onClick={handleAddStockWidget} className="mb-2 interactive-hover">
                <FaTable className="me-2" /> Add Stock Widget
              </Button>
              <Button variant="outline-primary" onClick={handleAddChartWidget} className="mb-2 interactive-hover">
                <FaChartLine className="me-2" /> Add Chart Widget
              </Button>
              <Button variant="outline-primary" onClick={handleAddIndicatorWidget} className="mb-2 interactive-hover">
                <FaChartBar className="me-2" /> Add Indicators
              </Button>
              <Button variant="outline-primary" onClick={handleAddPortfolioWidget} className="mb-2 interactive-hover">
                <FaChartPie className="me-2" /> Add Portfolio
              </Button>
            </div>
          </div>
        ) : (
          <div className="dashboard-grid">
            {positionedWidgets.map(widget => renderWidget(widget))}
          </div>
        )}
      </div>

      {/* Notification Center */}
      <NotificationCenter 
        show={showNotifications} 
        onHide={() => setShowNotifications(false)} 
      />
    </div>
  );
};

export default Dashboard; 