import { useState, useEffect } from 'react';
import { Button } from 'react-bootstrap';
import { FaUserPlus, FaSignInAlt } from 'react-icons/fa';
import AuthButtons from './AuthButtons';
import AuthModal from './AuthModal';
import { useWeb3 } from '../../context/Web3Context';
import { authService } from '../../services/AuthService';

const AuthManager = () => {
  const { account, isConnected } = useWeb3();
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState<'signin' | 'signup'>('signin');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check authentication status on mount and when account changes
  useEffect(() => {
    const checkAuth = async () => {
      const isAuth = authService.isAuthenticated();
      setIsAuthenticated(isAuth);
      
      // If wallet is connected but user is not authenticated, check if they have an account
      if (isConnected && !isAuth && account) {
        // Here you would typically check with your backend if this wallet address
        // has an account already, and if so, prompt them to sign in
        // For now, we'll just assume they need to sign up if not authenticated
      }
    };
    
    checkAuth();
  }, [account, isConnected]);

  const handleSignIn = () => {
    setModalMode('signin');
    setShowModal(true);
  };

  const handleSignUp = () => {
    setModalMode('signup');
    setShowModal(true);
  };

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
  };

  // If user is already authenticated with wallet, show the connected wallet
  if (isAuthenticated && isConnected) {
    return <AuthButtons />;
  }

  return (
    <>
      <div className="d-flex">
        <Button 
          variant="outline-light" 
          size="sm" 
          className="me-2 d-flex align-items-center"
          onClick={handleSignIn}
        >
          <FaSignInAlt className="me-1" />
          <span>Sign In</span>
        </Button>
        <Button 
          variant="primary" 
          size="sm"
          className="d-flex align-items-center"
          onClick={handleSignUp}
        >
          <FaUserPlus className="me-1" />
          <span>Sign Up</span>
        </Button>
      </div>

      <AuthModal 
        show={showModal} 
        onHide={() => setShowModal(false)} 
        mode={modalMode}
        onSuccess={handleAuthSuccess}
      />
    </>
  );
};

export default AuthManager; 