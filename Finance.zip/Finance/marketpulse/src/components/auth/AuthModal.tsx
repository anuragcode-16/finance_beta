import { useState } from 'react';
import { Modal, Button, Form, Spinner, Alert } from 'react-bootstrap';
import { FaWallet } from 'react-icons/fa';
import { useWeb3 } from '../../context/Web3Context';
import { authService } from '../../services/AuthService';

interface AuthModalProps {
  show: boolean;
  onHide: () => void;
  mode: 'signin' | 'signup';
  onSuccess?: () => void;
}

const AuthModal = ({ show, onHide, mode, onSuccess }: AuthModalProps) => {
  const { account, isConnected, connectWallet, signMessage } = useWeb3();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'connect' | 'details' | 'signing'>('connect');

  const handleConnectWallet = async () => {
    try {
      setError(null);
      await connectWallet();
      if (mode === 'signin') {
        setStep('signing');
      } else {
        setStep('details');
      }
    } catch (err) {
      setError('Failed to connect wallet. Please try again.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!account) {
      setError('Wallet not connected. Please connect your wallet first.');
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      setStep('signing');
      
      // Generate message to sign
      const message = authService.generateNonceMessage(account, mode);
      
      // Request signature from user
      const signature = await signMessage(message);
      
      // Authenticate with backend
      if (mode === 'signin') {
        await authService.signInWithEthereum(account, signature);
      } else {
        await authService.signUpWithEthereum(account, signature, { username, email });
      }
      
      // Close modal and notify parent of success
      onHide();
      if (onSuccess) {
        onSuccess();
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderConnectStep = () => (
    <div className="text-center py-4">
      <FaWallet size={48} className="mb-3 text-primary" />
      <h5>Connect Your Wallet</h5>
      <p className="text-muted">
        {mode === 'signin' 
          ? 'Connect your MetaMask wallet to sign in.' 
          : 'Connect your MetaMask wallet to create an account.'}
      </p>
      <Button 
        variant="primary" 
        onClick={handleConnectWallet} 
        disabled={isLoading}
        className="mt-3"
      >
        {isLoading ? (
          <>
            <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" className="me-2" />
            Connecting...
          </>
        ) : (
          <>Connect MetaMask</>
        )}
      </Button>
    </div>
  );

  const renderDetailsStep = () => (
    <Form onSubmit={handleSubmit}>
      <Form.Group className="mb-3">
        <Form.Label>Ethereum Address</Form.Label>
        <Form.Control
          type="text"
          value={account || ''}
          disabled
        />
        <Form.Text className="text-muted">
          This is your connected wallet address.
        </Form.Text>
      </Form.Group>
      
      <Form.Group className="mb-3">
        <Form.Label>Username</Form.Label>
        <Form.Control
          type="text"
          placeholder="Choose a username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
      </Form.Group>
      
      <Form.Group className="mb-3">
        <Form.Label>Email (optional)</Form.Label>
        <Form.Control
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <Form.Text className="text-muted">
          We'll never share your email with anyone else.
        </Form.Text>
      </Form.Group>
      
      <div className="d-grid gap-2">
        <Button variant="primary" type="submit" disabled={isLoading}>
          {isLoading ? (
            <>
              <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" className="me-2" />
              Processing...
            </>
          ) : (
            'Continue'
          )}
        </Button>
      </div>
    </Form>
  );

  const renderSigningStep = () => (
    <div className="text-center py-4">
      <Spinner animation="border" variant="primary" className="mb-3" />
      <h5>Waiting for Signature</h5>
      <p className="text-muted">
        Please check your MetaMask wallet and sign the message to {mode === 'signin' ? 'sign in' : 'complete registration'}.
      </p>
    </div>
  );

  const renderContent = () => {
    if (!isConnected) {
      return renderConnectStep();
    }
    
    switch (step) {
      case 'details':
        return renderDetailsStep();
      case 'signing':
        return renderSigningStep();
      default:
        return renderConnectStep();
    }
  };

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>
          {mode === 'signin' ? 'Sign In with MetaMask' : 'Sign Up with MetaMask'}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {error && <Alert variant="danger">{error}</Alert>}
        {renderContent()}
      </Modal.Body>
    </Modal>
  );
};

export default AuthModal; 