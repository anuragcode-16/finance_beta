import { Button, Spinner } from 'react-bootstrap';
import { FaWallet } from 'react-icons/fa';
import { useWeb3 } from '../../context/Web3Context';

const AuthButtons = () => {
  const { account, isConnected, isConnecting, connectWallet, disconnectWallet } = useWeb3();

  // Function to truncate Ethereum address for display
  const truncateAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  return (
    <div className="d-flex align-items-center">
      {isConnected ? (
        <div className="d-flex align-items-center">
          <span className="wallet-address">
            {truncateAddress(account || '')}
          </span>
          <Button 
            variant="outline-light" 
            size="sm" 
            onClick={disconnectWallet}
            className="wallet-button"
          >
            Sign Out
          </Button>
        </div>
      ) : (
        <Button 
          variant="primary" 
          onClick={connectWallet} 
          disabled={isConnecting}
          className="wallet-button d-flex align-items-center"
        >
          {isConnecting ? (
            <>
              <Spinner
                as="span"
                animation="border"
                size="sm"
                role="status"
                aria-hidden="true"
                className="me-2"
              />
              <span>Connecting...</span>
            </>
          ) : (
            <>
              <FaWallet className="me-2" />
              <span>Connect Wallet</span>
            </>
          )}
        </Button>
      )}
    </div>
  );
};

export default AuthButtons; 