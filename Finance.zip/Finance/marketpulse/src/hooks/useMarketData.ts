import { useState, useEffect } from 'react';
import { getStocks, getCryptos, getAssetBySymbol, getChartData } from '../services/marketService';
import { StockData, CryptoData, MarketAsset, ChartData } from '../types/market';

export const useStocks = () => {
  const [stocks, setStocks] = useState<StockData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStocks = async () => {
      try {
        setLoading(true);
        const data = await getStocks();
        setStocks(data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch stocks data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchStocks();
    
    // Refresh data every 30 seconds
    const intervalId = setInterval(fetchStocks, 30000);
    
    return () => clearInterval(intervalId);
  }, []);

  return { stocks, loading, error };
};

export const useCryptos = () => {
  const [cryptos, setCryptos] = useState<CryptoData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCryptos = async () => {
      try {
        setLoading(true);
        const data = await getCryptos();
        setCryptos(data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch cryptocurrency data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchCryptos();
    
    // Refresh data every 15 seconds (crypto prices change more frequently)
    const intervalId = setInterval(fetchCryptos, 15000);
    
    return () => clearInterval(intervalId);
  }, []);

  return { cryptos, loading, error };
};

export const useAssetDetails = (symbol: string, type: 'stock' | 'crypto') => {
  const [asset, setAsset] = useState<MarketAsset | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAssetDetails = async () => {
      if (!symbol) return;
      
      try {
        setLoading(true);
        const data = await getAssetBySymbol(symbol, type);
        setAsset(data);
        setError(null);
      } catch (err) {
        setError(`Failed to fetch ${type} details`);
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchAssetDetails();
    
    // Refresh data every 20 seconds
    const intervalId = setInterval(fetchAssetDetails, 20000);
    
    return () => clearInterval(intervalId);
  }, [symbol, type]);

  return { asset, loading, error };
};

export const useChartData = (symbol: string, type: 'stock' | 'crypto', timeframe: '1d' | '1w' | '1m' | '3m' | '1y' = '1m') => {
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchChartData = async () => {
      if (!symbol) return;
      
      try {
        setLoading(true);
        const data = await getChartData(symbol, type, timeframe);
        setChartData(data);
        setError(null);
      } catch (err) {
        setError(`Failed to fetch chart data`);
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchChartData();
  }, [symbol, type, timeframe]);

  return { chartData, loading, error };
}; 