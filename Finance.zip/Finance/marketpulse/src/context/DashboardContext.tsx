import { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { WidgetConfig } from '../types/market';
import { v4 as uuidv4 } from 'uuid';

// Default widgets for the dashboard
const defaultWidgets: WidgetConfig[] = [
  {
    id: 'stock-overview',
    type: 'price',
    title: 'Stock Overview',
    position: { x: 0, y: 0, width: 6, height: 4 },
  },
  {
    id: 'crypto-overview',
    type: 'price',
    title: 'Crypto Overview',
    position: { x: 6, y: 0, width: 6, height: 4 },
  },
  {
    id: 'aapl-chart',
    type: 'chart',
    title: 'AAPL Stock Chart',
    asset: 'AAPL',
    position: { x: 0, y: 4, width: 8, height: 6 },
    settings: { timeframe: '1m' },
  },
  {
    id: 'btc-chart',
    type: 'chart',
    title: 'Bitcoin Chart',
    asset: 'BTC',
    position: { x: 0, y: 10, width: 8, height: 6 },
    settings: { timeframe: '1m' },
  },
  {
    id: 'technical-indicators',
    type: 'indicator',
    title: 'Technical Indicators',
    asset: 'AAPL',
    position: { x: 8, y: 4, width: 4, height: 6 },
  },
];

interface DashboardContextType {
  widgets: WidgetConfig[];
  addWidget: (widget: Omit<WidgetConfig, 'id'>) => void;
  updateWidget: (id: string, updates: Partial<WidgetConfig>) => void;
  removeWidget: (id: string) => void;
  moveWidget: (id: string, position: { x: number; y: number }) => void;
  resizeWidget: (id: string, size: { width: number; height: number }) => void;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

export const DashboardProvider = ({ children }: { children: ReactNode }) => {
  const [widgets, setWidgets] = useState<WidgetConfig[]>(() => {
    // Try to get widgets from localStorage
    const savedWidgets = localStorage.getItem('dashboardWidgets');
    return savedWidgets ? JSON.parse(savedWidgets) : defaultWidgets;
  });

  // Save widgets to localStorage when they change
  useEffect(() => {
    localStorage.setItem('dashboardWidgets', JSON.stringify(widgets));
  }, [widgets]);

  const addWidget = (widget: Omit<WidgetConfig, 'id'>) => {
    const newWidget: WidgetConfig = {
      ...widget,
      id: uuidv4(),
    };
    setWidgets(prev => [...prev, newWidget]);
  };

  const updateWidget = (id: string, updates: Partial<WidgetConfig>) => {
    setWidgets(prev => 
      prev.map(widget => 
        widget.id === id ? { ...widget, ...updates } : widget
      )
    );
  };

  const removeWidget = (id: string) => {
    setWidgets(prev => prev.filter(widget => widget.id !== id));
  };

  const moveWidget = (id: string, position: { x: number; y: number }) => {
    setWidgets(prev => 
      prev.map(widget => 
        widget.id === id 
          ? { ...widget, position: { ...widget.position, ...position } } 
          : widget
      )
    );
  };

  const resizeWidget = (id: string, size: { width: number; height: number }) => {
    setWidgets(prev => 
      prev.map(widget => 
        widget.id === id 
          ? { ...widget, position: { ...widget.position, ...size } } 
          : widget
      )
    );
  };

  return (
    <DashboardContext.Provider value={{ 
      widgets, 
      addWidget, 
      updateWidget, 
      removeWidget, 
      moveWidget, 
      resizeWidget 
    }}>
      {children}
    </DashboardContext.Provider>
  );
};

export const useDashboard = (): DashboardContextType => {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error('useDashboard must be used within a DashboardProvider');
  }
  return context;
}; 